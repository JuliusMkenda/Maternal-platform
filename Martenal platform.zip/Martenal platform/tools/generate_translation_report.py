import re, json, glob, os
pattern = re.compile(r"t\(['\"]([a-z0-9_\.]+)['\"]\)")
keys = set()
for path in glob.glob('**/*.php', recursive=True):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            txt = f.read()
        for m in pattern.findall(txt):
            keys.add(m)
    except Exception:
        pass
langs = ['en','sw','fr','es']
base = {}
for l in langs:
    p = os.path.join('languages', f'{l}.json')
    try:
        with open(p,'r',encoding='utf-8') as f:
            base[l]=json.load(f)
    except Exception as e:
        base[l]={}

# helper
def get_nested(d, parts):
    v = d
    for p in parts:
        if isinstance(v, dict) and p in v:
            v = v[p]
        else:
            return None
    return v

def collect_all(d, prefix=''):
    out = []
    for k,v in d.items():
        full = (prefix + '.' + k) if prefix else k
        if isinstance(v, dict):
            out.extend(collect_all(v, full))
        else:
            out.append(full)
    return out

missing = {l:[] for l in langs}
for k in sorted(keys):
    parts = k.split('.')
    for l in langs:
        if get_nested(base.get(l,{}), parts) is None:
            missing[l].append(k)

# determine which keys were newly added by our earlier auto-fill (i.e., keys whose value equals English)
added = {l:[] for l in ['sw','fr','es']}
for l in ['sw','fr','es']:
    for k in sorted(keys):
        parts = k.split('.')
        en = get_nested(base['en'], parts)
        tr = get_nested(base.get(l,{}), parts)
        if tr is not None and tr == en and en is not None:
            added[l].append(k)

report_path = os.path.join('tools', 'translation_detailed_report.txt')
strings_path = os.path.join('tools', 'strings_for_translation.json')

with open(report_path,'w',encoding='utf-8') as f:
    f.write('TOTAL_KEYS_IN_TEMPLATES: %d\n' % len(keys))
    for l in langs:
        f.write('\nLANG %s\n' % l)
        f.write(' MISSING_KEYS: %d\n' % len(missing[l]))
        for k in missing[l]:
            f.write('  MISSING: %s\n' % k)
    f.write('\nPOTENTIAL_ADDED_KEYS_COPY_FROM_EN\n')
    for l in ['sw','fr','es']:
        f.write(' %s added_or_copied_count: %d\n' % (l, len(added[l])))
        for k in added[l]:
            f.write('  ADDED: %s\n' % k)
# Also export the English strings that were copied into other languages so they
# can be submitted to a translator or a translation API.
payload = {}
for l in ['sw','fr','es']:
    payload[l] = {}
    for k in added[l]:
        parts = k.split('.')
        v = base['en']
        for p in parts:
            v = v.get(p, {}) if isinstance(v, dict) else v
        payload[l][k] = v if not isinstance(v, dict) else ''

with open(strings_path,'w',encoding='utf-8') as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)

print('report_generated')
