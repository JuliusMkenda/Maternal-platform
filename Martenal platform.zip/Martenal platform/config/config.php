<?php
declare(strict_types=1);

define('APP_NAME', 'MomCare');

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? '') === '443' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptPath = dirname($_SERVER['SCRIPT_NAME'] ?? '/');
$basePath = rtrim(str_replace('\\', '/', $scriptPath), '/');
define('APP_URL', $scheme . '://' . $host . $basePath);

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'maternal_db');
define('DB_USER', 'root');
define('DB_PASS', '');

define('MPESA_CONSUMER_KEY', 'sandbox_consumer_key');
define('MPESA_CONSUMER_SECRET', 'sandbox_consumer_secret');
define('MPESA_SHORTCODE', '174379');
define('MPESA_PASSKEY', 'sandbox_passkey');

// Address Autocomplete API Keys
// Google Places API - https://console.cloud.google.com/
define('GOOGLE_PLACES_API_KEY', getenv('GOOGLE_PLACES_API_KEY') ?: '');
// Mapbox Search Box - https://account.mapbox.com/tokens/
define('MAPBOX_API_KEY', getenv('MAPBOX_API_KEY') ?: '');
