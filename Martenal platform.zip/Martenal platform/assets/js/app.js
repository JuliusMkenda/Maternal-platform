document.querySelectorAll('[data-confirm]').forEach((element) => {
    element.addEventListener('click', (event) => {
        if (!confirm(element.dataset.confirm)) {
            event.preventDefault();
        }
    });
});

// Hero background slideshow
document.addEventListener('DOMContentLoaded', function () {
    const heroBg = document.querySelector('.hero-bg');
    console.log('hero slideshow: DOMContentLoaded');
    if (!heroBg) {
        console.log('hero slideshow: .hero-bg not found');
        return;
    }

    let images = [];
    try {
        const raw = heroBg.getAttribute('data-images');
        images = raw ? JSON.parse(raw) : [];
    } catch (e) {
        console.error('hero slideshow: error parsing data-images', e);
        images = [];
    }

    // remove falsy entries
    images = images.filter(Boolean);
    console.log('hero slideshow: images loaded', images);
    if (!images.length) return;

    // shuffle images (Fisher-Yates)
    for (let i = images.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [images[i], images[j]] = [images[j], images[i]];
    }
    console.log('hero slideshow: images shuffled', images);

    const interval = parseInt(heroBg.getAttribute('data-interval')) || 5000;

    images.forEach((src, i) => {
        const slide = document.createElement('div');
        slide.className = 'slide' + (i === 0 ? ' active' : '');
        slide.style.background = `linear-gradient(135deg, rgba(233, 30, 99, 0.15) 0%, rgba(244, 143, 177, 0.1) 100%), url('${src}') center right / cover`;
        heroBg.appendChild(slide);
    });

    let current = 0;
    const slides = heroBg.querySelectorAll('.slide');
    setInterval(() => {
        const next = (current + 1) % slides.length;
        slides[current].classList.remove('active');
        slides[next].classList.add('active');
        current = next;
    }, interval);
});

