# 🌍 Multi-Language Implementation Guide

## Overview

MomCare platform now supports **4 languages**:
- 🇬🇧 **English** (en)
- 🇹🇿 **Swahili** (sw)
- 🇫🇷 **French** (fr)
- 🇪🇸 **Spanish** (es)

Users can switch languages at any time using the language selector in the navbar.

---

## 📁 Files Created/Modified

### Translation Files (New)
```
languages/
├── en.json        (English)
├── sw.json        (Swahili)
├── fr.json        (French)
└── es.json        (Spanish)
```

Each JSON file contains 12 sections with 100+ translation keys covering:
- `common` - Shared words & buttons
- `nav` - Navigation labels
- `auth` - Login/register forms
- `customer_dashboard` - Pregnancy tracking
- `notifications` - Notification center
- `products`, `services`, `resources`, `orders`, `bookings`
- `messages` - Success/error alerts
- `footer` - Footer links

### Code Files (Created/Updated)

| File | Change |
|------|--------|
| `includes/translations.php` | NEW - Core translation system |
| `public/_bootstrap.php` | Added translation include |
| `includes/header.php` | Added language selector dropdown |
| `public/login.php` | Converted to use translations |
| `public/customer_dashboard.php` | Converted to use translations |
| **Database** | Added `language` column to `users` table |

---

## 🎯 How It Works

### 1. Language Detection
On first visit, system detects language from:
1. User profile (if logged in)
2. Session storage
3. Browser Accept-Language header
4. Defaults to English if none detected

### 2. Language Selection
Users click the **language dropdown** in navbar (top right):
- Shows all 4 available languages
- Saves preference to database (if logged in)
- Stores in session
- Page refreshes with new language

### 3. Translation System
When displaying text:
```php
// Old (hardcoded)
<h1>Login</h1>

// New (translated)
<h1><?= t('auth.login_title') ?></h1>
```

The `t()` function:
- Gets current user's language
- Loads appropriate JSON file
- Returns translation or English fallback
- Caches in memory for performance

---

## 💾 Database Changes

Added column to `users` table:
```sql
ALTER TABLE users ADD COLUMN language VARCHAR(5) DEFAULT 'en' AFTER role_id
```

Stores user's language preference permanently.

---

## 📝 Translation Coverage

Currently translated:
- ✅ Navigation
- ✅ Login/Register forms
- ✅ Customer Dashboard
- ✅ Pregnancy tracking labels
- ✅ Common buttons & messages
- ✅ Dashboard metrics

Still need translation (next phase):
- Products page
- Services page
- Resources page
- Orders & Bookings pages
- Admin pages

---

## 🔧 Adding Translations to New Pages

### Step 1: Identify Strings
Find all user-visible text that should be translated.

### Step 2: Update All 4 JSON Files
Add the same key structure to each language file:

**languages/en.json:**
```json
{
  "products": {
    "title": "Products",
    "add_to_cart": "Add to Cart"
  }
}
```

**languages/sw.json:**
```json
{
  "products": {
    "title": "Bidhaa",
    "add_to_cart": "Ongeza kwenye Kikapu"
  }
}
```

Repeat for `fr.json` and `es.json`.

### Step 3: Update PHP File
Replace hardcoded text with translation function:

```php
// Before
<h1>Products</h1>
<button>Add to Cart</button>

// After
<h1><?= t('products.title') ?></h1>
<button><?= t('products.add_to_cart') ?></button>
```

---

## 🚀 Usage Examples

### Get Translated String
```php
t('auth.login_button')  // "Sign In" in current language
```

### Get Current Language
```php
$lang = get_current_language();  // 'en', 'sw', 'fr', or 'es'
```

### Set Language Programmatically
```php
set_user_language('sw');  // Switch to Swahili
```

### Get All Available Languages
```php
$langs = get_available_languages();
// Returns: ['en' => 'English', 'sw' => 'Swahili', 'fr' => 'Français', 'es' => 'Español']
```

---

## 🎨 Language Selector Location

Appears in navbar (top right corner):
- Desktop: Dropdown select box before user name
- Mobile: Same dropdown in collapsed menu
- Changes dynamically based on current language
- Auto-saves selection

---

## ⚙️ Configuration

### Available Languages
Defined in `includes/translations.php`:
```php
const AVAILABLE_LANGUAGES = ['en', 'sw', 'fr', 'es'];
const LANGUAGE_NAMES = [
    'en' => 'English',
    'sw' => 'Swahili',
    'fr' => 'Français',
    'es' => 'Español'
];
```

To add new language:
1. Create `languages/xx.json` (where xx is language code)
2. Add to `AVAILABLE_LANGUAGES` array
3. Add name to `LANGUAGE_NAMES` array
4. Provide translations for all keys

### Fallback Behavior
- If translation missing: Uses English
- If English also missing: Returns the translation key (e.g., "auth.login_title")
- If language file not found: Falls back to English

---

## 📊 Performance Notes

- Translation files cached in memory per session
- No database queries during page load (only on language change)
- JSON files lightweight (~50KB each)
- Minimal performance impact

---

## 🧪 Testing

### Test Language Switching
1. Go to any page
2. Click language selector in navbar
3. Choose different language
4. Verify page text updates
5. Refresh page - language persists
6. Log out and back in - preference saved

### Test Fallback
1. Add partial translation (missing a key)
2. Try to display that key
3. Should show English version
4. Check browser console for no errors

---

## 📋 Translation Checklist for Future Development

When creating new pages:
- [ ] Identify all user-visible text
- [ ] Add keys to all 4 JSON files
- [ ] Replace hardcoded strings with `t()` calls
- [ ] Test all 4 languages work
- [ ] Test fallback to English
- [ ] Verify language selector updates
- [ ] Check mobile responsiveness

---

## 🐛 Troubleshooting

### Translations not showing
**Solution:** Verify `t()` function being called and key exists in JSON file

### Language not saving
**Solution:** Check if `language` column added to `users` table and user is logged in

### Wrong language showing
**Solution:** Clear browser cache and session cookies, then reload

### JSON file errors
**Solution:** Validate JSON syntax - use online JSON validator to check all 4 files

---

## 📚 Related Files

- **System**: [includes/translations.php](../includes/translations.php)
- **Bootstrap**: [public/_bootstrap.php](../public/_bootstrap.php)
- **Header**: [includes/header.php](../includes/header.php)
- **English**: [languages/en.json](../languages/en.json)
- **Swahili**: [languages/sw.json](../languages/sw.json)
- **French**: [languages/fr.json](../languages/fr.json)
- **Spanish**: [languages/es.json](../languages/es.json)

---

## ✨ Next Steps

1. **Complete coverage** - Update all remaining pages with translations
2. **Admin translation panel** - Let non-technical users edit translations
3. **RTL support** - Add Arabic and other right-to-left languages
4. **Date/Currency formatting** - Format numbers/dates per language
5. **Pluralization** - Handle singular/plural forms per language

---

**Last Updated:** 2026-06-16
**Status:** Production Ready (Core pages translated)
