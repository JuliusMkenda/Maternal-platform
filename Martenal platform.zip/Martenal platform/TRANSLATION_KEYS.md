# Translation Keys Reference

## Common Translation Keys (Already Available)

### Common Words
- `common.home` - Home
- `common.about` - About
- `common.login` - Login
- `common.logout` - Logout
- `common.register` - Register
- `common.dashboard` - Dashboard
- `common.profile` - Profile
- `common.settings` - Settings
- `common.language` - Language
- `common.notifications` - Notifications
- `common.cart` - Cart
- `common.checkout` - Checkout
- `common.search` - Search
- `common.cancel` - Cancel
- `common.save` - Save
- `common.delete` - Delete
- `common.edit` - Edit
- `common.back` - Back
- `common.next` - Next
- `common.previous` - Previous
- `common.loading` - Loading...
- `common.error` - Error
- `common.success` - Success
- `common.welcome` - Welcome
- `common.hello` - Hello

### Navigation
- `nav.brand` - MomCare
- `nav.dashboard` - Dashboard
- `nav.services` - Services
- `nav.products` - Products
- `nav.resources` - Resources
- `nav.orders` - Orders
- `nav.bookings` - Bookings
- `nav.admin` - Admin
- `nav.seller` - Seller

### Authentication
- `auth.login_title` - Login to MomCare
- `auth.login_subtitle` - Access your account
- `auth.register_title` - Create Account
- `auth.register_subtitle` - Join MomCare
- `auth.email` - Email
- `auth.password` - Password
- `auth.confirm_password` - Confirm Password
- `auth.full_name` - Full Name
- `auth.phone` - Phone Number
- `auth.remember_me` - Remember me
- `auth.forgot_password` - Forgot password?
- `auth.no_account` - Don't have an account?
- `auth.have_account` - Already have an account?
- `auth.login_button` - Sign In
- `auth.register_button` - Sign Up
- `auth.access_denied` - Access Denied
- `auth.login_required` - You must be logged in to access this page

### Customer Dashboard
- `customer_dashboard.title` - Mother / Customer Dashboard
- `customer_dashboard.available_products` - Available products
- `customer_dashboard.recent_orders` - Recent orders
- `customer_dashboard.recent_bookings` - Recent bookings
- `customer_dashboard.pregnancy_progress` - Pregnancy Progress
- `customer_dashboard.weeks_pregnant` - Weeks Pregnant
- `customer_dashboard.current_phase` - Current Phase
- `customer_dashboard.weeks_remaining` - Weeks Remaining
- `customer_dashboard.expected_delivery` - Expected Delivery
- `customer_dashboard.upcoming_milestones` - 📅 Upcoming Milestones
- `customer_dashboard.quick_tips` - 💡 Quick Tips
- `customer_dashboard.clinic_appointments` - Keep your clinic appointments on schedule
- `customer_dashboard.prenatal_vitamins` - Take prenatal vitamins daily
- `customer_dashboard.balanced_diet` - Eat a balanced diet with iron-rich foods
- `customer_dashboard.danger_signs` - Report any danger signs immediately
- `customer_dashboard.hospital_bag` - Start preparing your hospital bag
- `customer_dashboard.read_care_guide` - Read Care Guide
- `customer_dashboard.recent_notifications` - 🔔 Recent Notifications
- `customer_dashboard.no_notifications` - No new notifications
- `customer_dashboard.view_all_notifications` - View all notifications

### Notifications
- `notifications.title` - Notifications
- `notifications.mark_all_read` - Mark all as read
- `notifications.no_notifications` - You have no notifications yet...
- `notifications.notification_stats` - Notification Stats
- `notifications.unread` - Unread
- `notifications.notification_types` - Notification Types
- `notifications.new` - New
- `notifications.milestone` - Milestone
- `notifications.clinic_reminder` - Clinic Reminder
- `notifications.new_product` - New Product
- `notifications.new_resource` - New Resource
- `notifications.payment` - Payment
- `notifications.booking` - Booking

### Products
- `products.title` - Products
- `products.all_products` - All Products
- `products.product_details` - Product Details
- `products.price` - Price
- `products.stock` - Stock
- `products.add_to_cart` - Add to Cart
- `products.in_stock` - In Stock
- `products.out_of_stock` - Out of Stock
- `products.quantity` - Quantity
- `products.description` - Description
- `products.reviews` - Reviews
- `products.rating` - Rating

### Services
- `services.title` - Services
- `services.available_services` - Available Services
- `services.book_service` - Book Service
- `services.service_details` - Service Details
- `services.consultant` - Consultant
- `services.duration` - Duration
- `services.cost` - Cost
- `services.availability` - Availability
- `services.login_to_book` - Login as a mother/customer to book services

### Resources
- `resources.title` - Resources
- `resources.educational_materials` - Educational Materials
- `resources.antenatal` - Antenatal Care
- `resources.danger_signs` - Danger Signs
- `resources.nutrition` - Nutrition
- `resources.mental_health` - Mental Health
- `resources.postpartum` - Postpartum Care
- `resources.read_more` - Read More

### Orders
- `orders.title` - Orders
- `orders.order_id` - Order ID
- `orders.date` - Date
- `orders.status` - Status
- `orders.total` - Total
- `orders.view_details` - View Details
- `orders.no_orders` - No orders yet
- `orders.pending` - Pending
- `orders.completed` - Completed
- `orders.cancelled` - Cancelled

### Bookings
- `bookings.title` - Bookings
- `bookings.booking_date` - Booking Date
- `bookings.booking_time` - Booking Time
- `bookings.consultant` - Consultant
- `bookings.no_bookings` - No bookings yet
- `bookings.cancel_booking` - Cancel Booking

### Messages
- `messages.success_created` - Created successfully
- `messages.success_updated` - Updated successfully
- `messages.success_deleted` - Deleted successfully
- `messages.error_occurred` - An error occurred
- `messages.please_fill_all_fields` - Please fill all required fields
- `messages.invalid_email` - Invalid email address
- `messages.password_mismatch` - Passwords do not match
- `messages.item_added_to_cart` - Item added to cart
- `messages.booking_confirmed` - Booking confirmed
- `messages.order_placed` - Order placed successfully

### Footer
- `footer.about_us` - About Us
- `footer.contact_us` - Contact Us
- `footer.privacy_policy` - Privacy Policy
- `footer.terms_of_service` - Terms of Service
- `footer.follow_us` - Follow Us
- `footer.copyright` - © 2024 MomCare. All rights reserved.

---

## Usage in Code

```php
// Simple translation
<?= t('auth.login_button') ?>

// With conditions
<?php if ($user): ?>
    <span><?= t('common.hello') ?> <?= e($user['full_name']) ?></span>
<?php endif; ?>

// In JavaScript strings (not recommended, use data attributes)
// Better to use PHP to output translations to data attributes

// With formatting
<div class="alert alert-<?= $success ? 'success' : 'danger' ?>">
    <?= $success ? t('messages.success_created') : t('messages.error_occurred') ?>
</div>
```

---

## Add Translation Key Format

When adding new keys, maintain this structure:

```json
{
  "section": {
    "subsection_item": "Display Text"
  }
}
```

Examples:
- ✅ `products.add_to_cart` - Good
- ✅ `customer_dashboard.pregnancy_weeks` - Good
- ❌ `addToCart` - Avoid camelCase
- ❌ `products.add-to-cart` - Avoid hyphens (use underscores)

---

## Quality Checklist

Before translating a new page:
- [ ] All user-facing text identified
- [ ] Key created in all 4 JSON files (en, sw, fr, es)
- [ ] PHP file updated with `t()` calls
- [ ] No hardcoded strings left in user-facing areas
- [ ] Tested in all 4 languages
- [ ] Fallback to English tested
- [ ] Mobile layout verified

---

**Total Keys Available:** 100+
**Languages:** 4 (English, Swahili, French, Spanish)
**Coverage:** Core platform (login, dashboard, notifications)
