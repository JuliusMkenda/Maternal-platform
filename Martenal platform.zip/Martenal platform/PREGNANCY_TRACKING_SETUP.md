# Pregnancy Tracking System - Setup Guide

## ✅ Implementation Status

### Completed
- ✅ Database schema created (`database/pregnancy_tracking.sql`)
- ✅ PHP backend functions created (`includes/pregnancy_tracking.php`)
- ✅ Pregnancy tracking included in bootstrap (`public/_bootstrap.php`)
- ✅ Notification bell added to navbar (`includes/header.php`)
- ✅ Notifications center page created (`public/notifications.php`)
- ✅ Customer dashboard enhanced with pregnancy calendar (`public/customer_dashboard.php`)
- ✅ Timeline CSS styling added (`assets/css/style.css`)
- ✅ Auto-notification on new products (`public/seller_dashboard.php`)
- ✅ Auto-notification on new resources (`public/resources.php`)

## 📋 Setup Instructions

### Step 1: Import Database Schema
**CRITICAL: This must be done first!**

1. Open phpMyAdmin (usually at http://localhost/phpmyadmin)
2. Select the `maternal_db` database
3. Click "Import"
4. Select file: `database/pregnancy_tracking.sql`
5. Click "Go" to import

**What gets created:**
- `pregnancy_progress` - Stores user's LMP, EDD, current week/trimester
- `pregnancy_milestones` - Clinic visits, ultrasounds, screenings, delivery prep events
- `notification_preferences` - User notification opt-in settings
- `user_notifications` - All notifications (system, product, milestone, clinic reminders)

### Step 2: Verify Bootstrap Includes
The file `public/_bootstrap.php` should now include:
```php
require_once __DIR__ . '/../includes/pregnancy_tracking.php';
```
✅ Already added - No action needed

### Step 3: Test the System

1. **Login as a Customer** (user role_id = 2)
2. **Go to Customer Dashboard** - Should show:
   - Pregnancy stats (weeks, trimester, due date)
   - Upcoming milestones calendar
   - Quick tips section
3. **Click notification bell** - Should show notification center
4. **Seller adds product** - Customers should get "new_product" notification
5. **Midwife adds resource** - Customers should get "new_resource" notification

## 🔧 Available Functions

### Core Functions (in `includes/pregnancy_tracking.php`)

```php
// Get pregnancy info
$stats = get_pregnancy_stats($user_id);
// Returns: weeks, trimester, due_date, upcoming_milestones, unread_count

$progress = get_pregnancy_progress($user_id);
// Returns: lmp_date, edd, current_week, trimester

// Milestone management
$milestones = get_pregnancy_milestones($user_id);
$upcoming = get_upcoming_milestones($user_id, 60); // Next 60 days

// Notifications
$unread = get_unread_notification_count($user_id);
$notifications = get_user_notifications($user_id, 10); // 10 most recent
create_notification($user_id, $type, $title, $message);
mark_notification_read($notification_id);
mark_all_notifications_read($user_id);

// Admin/Background
send_due_milestone_notifications(); // Run daily via cron
```

## 📱 Pages Updated

| Page | Changes |
|------|---------|
| `customer_dashboard.php` | Added pregnancy calendar, milestones timeline |
| `notifications.php` | NEW - Full notification center with filtering |
| `includes/header.php` | Added notification bell with unread badge |
| `public/seller_dashboard.php` | Products now send notifications to all customers |
| `public/resources.php` | Resources now send notifications to all customers |
| `assets/css/style.css` | Added `.timeline` and `.notification-item` styles |

## 🎨 UI Components

### Timeline (Pregnancy Milestones)
```html
<div class="timeline">
    <div class="timeline-item">
        <div class="timeline-marker" style="background: #E91E63;">
            <i class="bi bi-calendar-event"></i>
        </div>
        <h6>Clinic Visit</h6>
        <small>March 15, 2024</small>
    </div>
</div>
```

### Notification Badge
Shows unread count on bell icon in navbar

### Metric Cards
Display pregnancy progress at top of dashboard:
- Current Weeks
- Trimester Phase
- Weeks Remaining
- Expected Delivery Date

## 🔔 Notification Types

| Type | Trigger | Icon |
|------|---------|------|
| `milestone` | Milestone date reached | 📅 Calendar |
| `clinic_reminder` | Clinic appointment | 🏥 Hospital |
| `new_product` | Seller adds product | 🛍️ Bag |
| `new_resource` | Midwife adds resource | 📖 Journal |
| `payment` | Payment processed | 💰 Wallet |
| `booking` | Booking confirmed | ✓ Check |

## 📊 Milestone Categories

The system supports these milestone types:
- `antenatal` - Regular clinic checkups
- `ultrasound` - Ultrasound scans
- `screening` - Blood tests, screening tests
- `delivery_prep` - Hospital bag, birth plan
- `postpartum` - After birth care
- `general` - General information

## 🛠️ Advanced Configuration

### Automatic Milestone Notifications
Add to a cron job or admin dashboard task:
```php
// Run daily at 8 AM
send_due_milestone_notifications();
```

### Custom Notification Creation
```php
create_notification(
    user_id: 5,
    type: 'clinic_reminder',
    title: 'Clinic Visit Tomorrow',
    message: 'Remember your checkup at City Hospital at 2 PM'
);
```

### User Notification Preferences
Customers can opt-out of certain notification types via their profile page (to be created).

## 🐛 Troubleshooting

### Notifications not showing
1. Check database import was successful
2. Verify `pregnancy_tracking.php` is included in `_bootstrap.php`
3. Check user role_id = 2 (customer)

### Timeline not displaying
1. Verify CSS file loaded (check browser inspector)
2. Ensure `get_milestone_color()` and `get_milestone_icon()` functions exist
3. Check for JavaScript errors in console

### No pregnancy data showing
1. Customer must have a pregnancy_progress record
2. LMP date must be set (manually add in database or create setup form)
3. Call `get_pregnancy_stats()` to verify data exists

## 📝 Sample Test Data

Database import includes:
- 5 test customers with pregnancy data
- 13 sample milestones
- 10 sample notifications
- Default notification preferences

**Test Credentials:**
- Customer 1: ID 2
- Customer 2: ID 3
- etc.

## 🎯 Next Steps

1. **Import the database schema** (Step 1 above)
2. **Test pregnancy tracking** on customer dashboard
3. **Test notifications** by adding a new product as seller
4. **(Optional) Create pregnancy setup form** for new customers
5. **(Optional) Setup cron job** for daily milestone notifications

## 📖 Related Files

- Schema: [database/pregnancy_tracking.sql](../database/pregnancy_tracking.sql)
- Functions: [includes/pregnancy_tracking.php](../includes/pregnancy_tracking.php)
- Dashboard: [public/customer_dashboard.php](../public/customer_dashboard.php)
- Notifications: [public/notifications.php](../public/notifications.php)
- Styles: [assets/css/style.css](../assets/css/style.css)

---

**Last Updated:** 2024
**Status:** Ready for Production
