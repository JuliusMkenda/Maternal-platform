# Address Autocomplete Setup Guide

## Overview

Your MomCare platform now includes a **production-ready address autocomplete** system that captures:
- Full address
- City
- Postal code
- Latitude & longitude coordinates

The system uses **Google Places API** as the primary provider with **OpenStreetMap (Nominatim)** as an automatic fallback.

---

## Features

✅ **Address Capture**: Full address, city, postal code, coordinates  
✅ **Modern UI**: Clean dropdown with icons, loading states, and error handling  
✅ **Keyboard Navigation**: Arrow keys, Enter to select, Escape to close  
✅ **Dual Provider**: Google Places (premium) + OSM Nominatim (free fallback)  
✅ **Session Tokens**: Google Places session tokens for billing optimization  
✅ **Component Parsing**: Automatic extraction of address components  
✅ **Mobile Friendly**: Responsive design with Bootstrap 5  

---

## Setup Instructions

### Option 1: Google Places API (Recommended for Production)

#### Step 1: Create a Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project: **Project Name** → "MomCare"
3. Enable billing (required for Maps APIs)

#### Step 2: Enable Required APIs

1. Search for "Places API" → **Enable**
2. Search for "Maps JavaScript API" → **Enable**
3. Search for "Geocoding API" → **Enable** (optional, for advanced features)

#### Step 3: Create an API Key

1. Go to **Credentials** → **Create Credentials** → **API Key**
2. Copy the generated API key
3. (Optional) Restrict the key:
   - Application restrictions: **HTTP referrers**
   - Add: `http://localhost/*` and your production domain

#### Step 4: Set the API Key

**Option A: Environment Variable (Recommended)**
```bash
# For Windows PowerShell (XAMPP Apache):
[Environment]::SetEnvironmentVariable("GOOGLE_PLACES_API_KEY", "YOUR_API_KEY_HERE", "User")
# Restart Apache/XAMPP after setting
```

**Option B: Direct Config (Development Only)**
```php
// In config/config.php, replace:
define('GOOGLE_PLACES_API_KEY', getenv('GOOGLE_PLACES_API_KEY') ?: '');

// With:
define('GOOGLE_PLACES_API_KEY', 'YOUR_API_KEY_HERE');
```

#### Step 5: Verify Installation

1. Start XAMPP (Apache + MySQL)
2. Visit: `http://localhost/Martenal%20platform/public/checkout.php`
3. Log in with: `amina@example.com` / `password`
4. Add products to cart
5. Go to checkout
6. Type an address (e.g., "Kigamboni, Dar es Salaam")
7. See Google Places suggestions appear

---

### Option 2: Mapbox Search Box (Alternative)

#### Step 1: Create Mapbox Account

1. Go to [Mapbox](https://account.mapbox.com/auth/signup/)
2. Create account and verify email
3. Go to **Tokens** → **Create a token**
4. Give it a name: "MomCare Autocomplete"
5. Ensure **Public scopes** includes `search:query`

#### Step 2: Add Mapbox to config.php

```php
// In config/config.php:
define('MAPBOX_API_KEY', getenv('MAPBOX_API_KEY') ?: 'YOUR_MAPBOX_KEY_HERE');
```

#### Step 3: Update checkout.php (optional Mapbox integration)

The current implementation uses Google Places first. To add Mapbox as an alternative:

```javascript
// Add this after the Google Places section in checkout.php:
const mapboxKey = '<?= defined("MAPBOX_API_KEY") ? e(MAPBOX_API_KEY) : "" ?>';
if (mapboxKey && !window.google) {
    // Load Mapbox Search Box
    fetchMapboxSuggestions(query);
}
```

---

## Fallback to OpenStreetMap (Free Option)

If you **don't set a Google API key**, the system automatically falls back to **OpenStreetMap (Nominatim)**:

- ✅ **Free** - No API key required
- ✅ **Works** - Uses server-side proxy (`public/nominatim.php`)
- ⚠️ **Rate Limited** - ~1 request per second recommended
- ⚠️ **Less Accurate** - Regional data varies

The fallback works automatically—no configuration needed!

---

## Database Schema

The system stores address data in the `orders` table:

```sql
CREATE TABLE orders (
    id INT PRIMARY KEY,
    user_id INT,
    total_amount DECIMAL(10, 2),
    status VARCHAR(50),
    delivery_address TEXT NOT NULL,
    delivery_lat DECIMAL(10, 7),
    delivery_lng DECIMAL(10, 7),
    created_at TIMESTAMP
);
```

---

## API Responses

### Google Places Response Structure
```json
{
    "place_id": "ChIJ...",
    "formatted_address": "123 Mwalimu Julius Nyerere Rd, Dar es Salaam, Tanzania",
    "geometry": {
        "location": {
            "lat": -6.8,
            "lng": 39.3
        }
    },
    "address_components": [
        {
            "long_name": "Kigamboni",
            "types": ["locality"]
        },
        {
            "long_name": "14101",
            "types": ["postal_code"]
        }
    ]
}
```

### OpenStreetMap (Nominatim) Response
```json
{
    "display_name": "Kigamboni, Dar es Salaam, Tanzania",
    "lat": "-6.8",
    "lon": "39.3",
    "address": {
        "city": "Dar es Salaam",
        "postcode": "14101"
    }
}
```

---

## Code Examples

### PHP - Retrieve Address Data from Order

```php
<?php
// In your order detail page:
$stmt = db()->prepare('SELECT delivery_address, delivery_lat, delivery_lng FROM orders WHERE id = ?');
$stmt->execute([$orderId]);
$order = $stmt->fetch();

echo "Address: " . $order['delivery_address'];
echo "Coordinates: " . $order['delivery_lat'] . ", " . $order['delivery_lng'];
?>
```

### JavaScript - Manual Address Selection

```javascript
// Programmatically set address (e.g., from saved location):
const savedAddress = "Kigamboni, Dar es Salaam, Tanzania";
const savedLat = "-6.8";
const savedLng = "39.3";

document.getElementById('delivery_address').value = savedAddress;
document.getElementById('delivery_lat').value = savedLat;
document.getElementById('delivery_lng').value = savedLng;
document.getElementById('delivery_city').value = "Dar es Salaam";
document.getElementById('delivery_postal_code').value = "14101";
```

---

## Troubleshooting

### Issue: "No results found" appears

**Cause**: API key missing or invalid  
**Solution**: 
- Verify API key in `config/config.php`
- Check Google Cloud Console for quota/billing issues
- Fallback to OSM will work automatically

### Issue: Address dropdown doesn't appear

**Cause**: JavaScript error  
**Solution**:
```bash
# Open browser console (F12)
# Look for errors related to:
# - Google Maps API load failure
# - CORS issues
# - JavaScript syntax errors
```

### Issue: CORS errors from nominatim.org

**Solution**: Already handled! The system uses a server-side proxy (`public/nominatim.php`) to avoid CORS.

### Issue: Only getting 1-2 results

**Solution**: 
- Add more specific search terms
- Google Places limits results to 6 by default (configurable in code)
- Try with city/postal code if available

---

## Performance Tips

1. **Session Tokens**: Google Places uses session tokens to reduce billing. The code auto-generates and rotates them.
2. **Debounce**: Search is debounced at 300ms to reduce API calls.
3. **Component Parsing**: City and postal code are parsed server-side for Nominatim.
4. **Caching**: Consider caching recent searches in localStorage for returning users.

---

## Security Considerations

1. **API Key Restrictions**: Set HTTP referrer restrictions in Google Cloud Console
2. **Environment Variables**: Never commit API keys to version control
3. **HTTPS**: Use HTTPS in production (Google requires it for some APIs)
4. **Rate Limiting**: Implement server-side rate limiting for `nominatim.php`
5. **Input Validation**: Address is validated server-side during checkout

---

## Files Modified

- `config/config.php` - Added API key constants
- `includes/header.php` - Google Places script injection hook
- `public/checkout.php` - Complete autocomplete implementation
- `public/nominatim.php` - Server-side OSM proxy (existing)

---

## Support & Resources

- **Google Places API Docs**: https://developers.google.com/maps/documentation/places
- **Mapbox Search Box**: https://docs.mapbox.com/mapbox-gl-js/example/mapbox-gl-geocoder/
- **OpenStreetMap Nominatim**: https://nominatim.org/release-docs/latest/

---

## Next Steps

1. ✅ Choose your provider (Google or Mapbox or free OSM)
2. ✅ Set up API key in environment or config
3. ✅ Test on checkout page
4. ✅ Verify coordinates are saved in database
5. ✅ Display on order confirmation/tracking page
6. ✅ (Optional) Add map visualization with leaflet.js

---

**Happy shipping! 🚚📍**
