-- Seed demo calendar events for user Amina (user_id = 2)
INSERT INTO calendar_events (user_id, title, start, `end`, all_day, notes) VALUES
(2, 'First ANC visit', '2026-07-02 09:00:00', '2026-07-02 09:30:00', 0, 'Bring clinic card and previous records'),
(2, 'Ultrasound appointment', '2026-08-15 10:00:00', '2026-08-15 10:30:00', 0, 'Fasting not required'),
(2, 'Birth prep class', '2026-09-01 00:00:00', NULL, 1, 'Group session at community center');
