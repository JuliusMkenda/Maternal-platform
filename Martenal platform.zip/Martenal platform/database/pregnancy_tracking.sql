-- Pregnancy tracking and enhanced notifications
-- Run this after the main maternal_db.sql to add new features

CREATE TABLE pregnancy_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    last_menstrual_period DATE NOT NULL,
    expected_due_date DATE NOT NULL,
    current_week INT,
    trimester INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE pregnancy_milestones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pregnancy_id INT NOT NULL,
    milestone_date DATE NOT NULL,
    title VARCHAR(160) NOT NULL,
    description TEXT,
    category ENUM('antenatal','ultrasound','screening','delivery_prep','postpartum','general') NOT NULL,
    is_completed BOOLEAN DEFAULT FALSE,
    notification_sent BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pregnancy_id) REFERENCES pregnancy_progress(id) ON DELETE CASCADE
);

CREATE TABLE notification_preferences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    notify_clinic_due BOOLEAN DEFAULT TRUE,
    notify_new_products BOOLEAN DEFAULT TRUE,
    notify_new_resources BOOLEAN DEFAULT TRUE,
    notify_payment BOOLEAN DEFAULT TRUE,
    notify_bookings BOOLEAN DEFAULT TRUE,
    notify_milestones BOOLEAN DEFAULT TRUE,
    preferred_channel ENUM('sms','email','both') DEFAULT 'both',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE user_notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('clinic_reminder','new_product','new_resource','payment','booking','milestone','system') NOT NULL,
    title VARCHAR(160) NOT NULL,
    message TEXT NOT NULL,
    related_id INT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_read (user_id, is_read),
    INDEX idx_created (created_at DESC)
);

-- Sample pregnancy data for demo customers
INSERT INTO pregnancy_progress (user_id, last_menstrual_period, expected_due_date, current_week, trimester) VALUES
(2, DATE_SUB(NOW(), INTERVAL 18 WEEK), DATE_ADD(NOW(), INTERVAL 22 WEEK), 18, 2),
(3, DATE_SUB(NOW(), INTERVAL 8 WEEK), DATE_ADD(NOW(), INTERVAL 32 WEEK), 8, 1),
(4, DATE_SUB(NOW(), INTERVAL 35 WEEK), DATE_ADD(NOW(), INTERVAL 5 WEEK), 35, 3),
(5, DATE_SUB(NOW(), INTERVAL 12 WEEK), DATE_ADD(NOW(), INTERVAL 28 WEEK), 12, 2),
(6, DATE_SUB(NOW(), INTERVAL 6 WEEK), DATE_ADD(NOW(), INTERVAL 34 WEEK), 6, 1);

-- Insert pregnancy milestones for customers
INSERT INTO pregnancy_milestones (pregnancy_id, milestone_date, title, description, category, is_completed) VALUES
(1, DATE_ADD(NOW(), INTERVAL 4 WEEK), 'First Trimester Scan (12-14 weeks)', 'Dating scan and nuchal translucency measurement', 'ultrasound', FALSE),
(1, DATE_ADD(NOW(), INTERVAL 2 WEEK), 'Anatomy Scan Preparation', 'Prepare questions for 20-week anatomy scan', 'general', FALSE),
(1, DATE_ADD(NOW(), INTERVAL 3 WEEK), 'Antenatal Clinic Visit', 'Monthly antenatal check-up', 'antenatal', FALSE),
(2, DATE_ADD(NOW(), INTERVAL 2 WEEK), 'First Clinic Visit', 'Initial antenatal registration and screening', 'antenatal', FALSE),
(2, DATE_ADD(NOW(), INTERVAL 4 WEEK), 'Early Pregnancy Scan', 'Confirm pregnancy viability and dating', 'ultrasound', FALSE),
(2, DATE_ADD(NOW(), INTERVAL 8 WEEK), 'Blood Testing Week', 'Complete first trimester blood tests', 'screening', FALSE),
(3, DATE_ADD(NOW(), INTERVAL 1 WEEK), 'Hospital Bag Preparation', 'Prepare and pack hospital bag', 'delivery_prep', FALSE),
(3, DATE_ADD(NOW(), INTERVAL 2 WEEK), 'Final Check-up', 'Pre-delivery final antenatal assessment', 'antenatal', FALSE),
(3, DATE_ADD(NOW(), INTERVAL 5 WEEK), 'Expected Delivery Date', 'Baby arrival expected around this date', 'delivery_prep', FALSE),
(4, DATE_ADD(NOW(), INTERVAL 1 WEEK), 'Anatomy Scan', '20-week structural fetal assessment', 'ultrasound', TRUE),
(4, DATE_ADD(NOW(), INTERVAL 2 WEEK), 'Postpartum Planning', 'Plan postpartum care and support', 'postpartum', FALSE),
(5, DATE_ADD(NOW(), INTERVAL 3 WEEK), 'Glucose Screening', '24-week gestational diabetes screening', 'screening', FALSE),
(5, DATE_ADD(NOW(), INTERVAL 5 WEEK), 'Third Trimester Check', 'Monitor baby position and growth', 'antenatal', FALSE);

-- Insert notification preferences for all customers
INSERT INTO notification_preferences (user_id, notify_clinic_due, notify_new_products, notify_new_resources, notify_payment, notify_bookings, notify_milestones, preferred_channel) VALUES
(2, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 'both'),
(3, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 'both'),
(4, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, 'email'),
(5, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 'sms'),
(6, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 'both');

-- Sample notification feed entries
INSERT INTO user_notifications (user_id, type, title, message, is_read) VALUES
(2, 'milestone', 'Upcoming: Anatomy Scan Preparation', 'Your 20-week anatomy scan is in 2 weeks. Start preparing your questions.', FALSE),
(2, 'new_product', 'New Product: Hospital Bag Set', 'We added a new Hospital Bag Set to help you prepare for delivery day.', FALSE),
(2, 'clinic_reminder', 'Clinic Visit Due', 'Your next antenatal clinic visit is scheduled. Remember to carry your clinic card.', FALSE),
(3, 'clinic_reminder', 'First Clinic Visit Coming Up', 'Book your first antenatal clinic visit within the next 2 weeks.', FALSE),
(3, 'new_resource', 'New Resource: Pregnancy Nutrition', 'Read our new guide on iron and folate during pregnancy.', TRUE),
(4, 'milestone', 'Congratulations!', 'Your anatomy scan is complete. Everything looks great!', TRUE),
(4, 'clinic_reminder', 'Time to Prepare', 'Start preparing your hospital bag. Delivery is expected in 5 weeks.', FALSE),
(5, 'payment', 'Payment Received', 'Your payment for prenatal vitamins has been confirmed. Order #4 processing.', TRUE),
(5, 'booking', 'Consultation Confirmed', 'Your nutrition counselling session with Neema is confirmed for June 15.', TRUE),
(6, 'new_product', 'New: Pregnancy Support Belt', 'Check out our new pregnancy support belt for back and belly comfort.', FALSE);
