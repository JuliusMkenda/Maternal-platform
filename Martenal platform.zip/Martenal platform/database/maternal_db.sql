﻿CREATE DATABASE IF NOT EXISTS maternal_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE maternal_db;



CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(40) NOT NULL UNIQUE,
    label VARCHAR(80) NOT NULL
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT NOT NULL,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    phone VARCHAR(30) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE
);

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT NOT NULL,
    category_id INT NOT NULL,
    name VARCHAR(160) NOT NULL,
    short_description VARCHAR(255),
    description TEXT,
    price DECIMAL(12,2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    image_url VARCHAR(500),
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES users(id),
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    midwife_id INT NOT NULL,
    name VARCHAR(160) NOT NULL,
    description TEXT,
    price DECIMAL(12,2) NOT NULL,
    duration_minutes INT NOT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    FOREIGN KEY (midwife_id) REFERENCES users(id)
);

CREATE TABLE resources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic VARCHAR(100) NOT NULL,
    title VARCHAR(180) NOT NULL,
    body TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_cart_line (user_id, product_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(12,2) NOT NULL,
    status ENUM('pending_payment','escrow_hold','confirmed','processing','delivered','cancelled') NOT NULL DEFAULT 'pending_payment',
    delivery_address TEXT NOT NULL,
    delivery_lat DECIMAL(10,7) NULL,
    delivery_lng DECIMAL(10,7) NULL,
    receipt_confirmed_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(12,2) NOT NULL,
    seller_notes TEXT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    service_id INT NOT NULL,
    midwife_id INT NOT NULL,
    booking_date DATE NOT NULL,
    booking_time TIME NOT NULL,
    status ENUM('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (service_id) REFERENCES services(id),
    FOREIGN KEY (midwife_id) REFERENCES users(id)
);

CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    user_id INT NOT NULL,
    method VARCHAR(80) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    status ENUM('otp_sent','paid','failed') NOT NULL DEFAULT 'otp_sent',
    escrow_status ENUM('held','release_scheduled','released') NOT NULL DEFAULT 'released',
    payout_status ENUM('pending','scheduled','paid') NOT NULL DEFAULT 'pending',
    escrow_released_at DATETIME NULL,
    payout_date DATETIME NULL,
    transaction_reference VARCHAR(120),
    paid_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    channel ENUM('sms','email') NOT NULL,
    subject VARCHAR(160) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('queued','sent','failed') NOT NULL DEFAULT 'queued',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

INSERT INTO roles (id, name, label) VALUES
(1,'admin','Administrator'),(2,'customer','Mother / Customer'),(3,'midwife','Midwife / Consultant'),(4,'seller','Product Seller');

INSERT INTO users (id, role_id, full_name, email, phone, password_hash, status) VALUES
(1,1,'MomCare Admin','admin@momcare.tz','255700000001','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(2,2,'Amina Hassan','amina@example.com','255700000002','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(3,2,'Rehema Juma','rehema@example.com','255700000003','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(4,2,'Fatma Said','fatma@example.com','255700000004','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(5,2,'Grace Mushi','grace@example.com','255700000005','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(6,2,'Zawadi Ally','zawadi@example.com','255700000006','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(7,3,'Neema Mwakalinga','neema.midwife@example.com','255700000007','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(8,3,'Dr Sara Kimaro','sara.consult@example.com','255700000008','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(9,3,'Mary Joseph','mary.midwife@example.com','255700000009','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(10,4,'MamaShop Tanzania','seller@mamashop.tz','255700000010','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(11,4,'Afya Mama Supplies','seller2@momcare.tz','255700000011','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active'),
(12,4,'BabyCare Dar','seller3@momcare.tz','255700000012','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','active');

INSERT INTO categories (id, name, slug) VALUES
(1,'Maternity Wear','maternity-wear'),(2,'Prenatal Vitamins','prenatal-vitamins'),(3,'Baby Essentials','baby-essentials'),(4,'Postpartum Care','postpartum-care'),
(5,'Feeding Support','feeding-support'),(6,'Hygiene Kits','hygiene-kits'),(7,'Pregnancy Monitoring','pregnancy-monitoring'),(8,'Hospital Bag','hospital-bag'),
(9,'Nutrition','nutrition'),(10,'Safety','safety'),(11,'Wellness','wellness'),(12,'Learning Materials','learning-materials');

INSERT INTO products (id, seller_id, category_id, name, short_description, description, price, stock_quantity, image_url, status) VALUES
(1,10,1,'Comfort Maternity Dress','Breathable cotton dress','Soft maternity dress for daily wear and clinic visits.',45000,24,'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=900&q=80','active'),
(2,11,2,'Prenatal Iron Plus','Iron and folic support','Daily prenatal supplement for pregnancy nutrition support.',18000,60,'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=900&q=80','active'),
(3,12,3,'Newborn Starter Pack','Essential newborn kit','Diapers, wipes, baby soap, towel, and receiving blanket.',65000,18,'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?auto=format&fit=crop&w=900&q=80','active'),
(4,10,4,'Postpartum Recovery Kit','Care kit after delivery','Pads, peri bottle, soothing gel, and hygiene supplies.',52000,20,'https://images.unsplash.com/photo-1600959907703-125ba1374a12?auto=format&fit=crop&w=900&q=80','active'),
(5,11,5,'Breastfeeding Pillow','Ergonomic feeding support','Comfortable pillow for breastfeeding positioning.',38000,22,'https://images.unsplash.com/photo-1546015720-b8b30df5aa27?auto=format&fit=crop&w=900&q=80','active'),
(6,12,6,'Mama Hygiene Kit','Clinic-ready hygiene pack','Sanitizer, soap, wipes, masks, and disposable bags.',22000,40,'https://images.unsplash.com/photo-1583947581924-a31bd94f32f1?auto=format&fit=crop&w=900&q=80','active'),
(7,10,7,'Digital Blood Pressure Monitor','Home BP tracking','Easy-to-use monitor for pregnancy blood pressure checks.',85000,12,'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=900&q=80','active'),
(8,11,8,'Hospital Bag Set','Prepared delivery bag','Organized bag with checklist pockets for delivery day.',72000,15,'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80','active'),
(9,12,9,'Mama Nutrition Porridge','Fortified nutrition mix','Energy and micronutrient fortified porridge flour.',16000,55,'https://images.unsplash.com/photo-1606787366850-de6330128bfc?auto=format&fit=crop&w=900&q=80','active'),
(10,10,10,'Infant Car Seat','Safety travel seat','Certified infant seat for safe family travel.',145000,9,'https://images.unsplash.com/photo-1578898886225-c7c894047899?auto=format&fit=crop&w=900&q=80','active'),
(11,11,11,'Pregnancy Support Belt','Back and belly support','Adjustable support belt for late pregnancy comfort.',32000,30,'https://images.unsplash.com/photo-1576765607924-ead79b257a71?auto=format&fit=crop&w=900&q=80','active'),
(12,12,12,'Antenatal Care Guide','Swahili learning booklet','Simple guide for pregnancy danger signs and preparation.',9000,80,'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&w=900&q=80','active');

INSERT INTO services (id, midwife_id, name, description, price, duration_minutes, status) VALUES
(1,7,'Antenatal Check-in','Remote pregnancy check-in and danger sign review.',15000,30,'active'),
(2,8,'Nutrition Counselling','Pregnancy nutrition planning and anemia prevention guidance.',18000,45,'active'),
(3,9,'Birth Preparedness Session','Delivery plan, hospital bag, transport and emergency planning.',20000,45,'active'),
(4,7,'Postpartum Follow-up','Recovery, bleeding checks, mood and breastfeeding support.',15000,30,'active'),
(5,8,'Lactation Support','Breastfeeding latch, pain and milk supply guidance.',18000,40,'active'),
(6,9,'Newborn Care Coaching','Cord care, bathing, sleep safety and warning signs.',20000,45,'active'),
(7,7,'High-Risk Referral Review','Screening conversation to guide facility referral.',25000,45,'active'),
(8,8,'Family Planning Advice','Postpartum contraception options and counselling.',16000,30,'active'),
(9,9,'Teen Mother Support','Confidential guidance for young mothers.',12000,30,'active'),
(10,7,'Clinic Visit Preparation','Questions and records to prepare for ANC visit.',10000,25,'active'),
(11,8,'Mental Wellness Check','Pregnancy and postpartum emotional wellbeing support.',17000,35,'active'),
(12,9,'Partner Education Session','Family support and shared birth preparedness.',22000,50,'active');

INSERT INTO resources (topic, title, body) VALUES
('Antenatal','When to start ANC','Start antenatal care as soon as pregnancy is suspected, ideally within the first 12 weeks. Keep scheduled visits for blood pressure checks, urine and blood tests, HIV/syphilis screening, baby growth monitoring, supplements, counselling, and birth preparation. Carry your clinic card and ask questions about warning signs, nutrition, safe medicines, and your expected delivery date.'),
('Danger Signs','Pregnancy danger signs','Seek urgent care for heavy bleeding, convulsions, fainting, severe abdominal pain, severe headache, blurred vision, swollen face or hands, high fever, difficulty breathing, repeated vomiting, or reduced baby movement after 20 weeks. After birth, danger signs include heavy bleeding, fever, bad-smelling discharge, severe pain, confusion, or thoughts of self-harm.'),
('Nutrition','Iron and folate','Eat a varied diet with staples, beans or animal protein, vegetables, fruit, and healthy fats where available. Take iron, folic acid, calcium, or other supplements as directed by a health worker. Drink safe water, avoid alcohol and smoking, and seek help if you feel weak, dizzy, lose weight, or cannot keep food down.'),
('Birth Plan','Preparing for delivery','Choose the delivery facility, know the route, estimate transport costs, and arrange backup transport. Prepare a hospital bag with clinic card, clean clothes, baby clothes, pads, soap, diapers, and required supplies. Save emergency contacts for family, transport, clinic, and a blood donor if advised.'),
('Postpartum','After birth checks','Attend postnatal checks, especially within the first two days and again as advised. Monitor bleeding, fever, pain, wound healing, urination, breast pain, mood changes, and breastfeeding. Return urgently for heavy bleeding, fever, severe pain, bad-smelling discharge, or worsening sadness.'),
('Breastfeeding','Early breastfeeding','Start breastfeeding within the first hour after birth when possible. Feed on demand day and night, make sure the baby has a deep latch, and ask for help if feeding is painful, nipples crack, breasts become hot and swollen, milk supply feels low, or the baby is not gaining weight.'),
('Newborn','Cord care','Keep the baby warm, feed often, and keep the cord clean and dry. Do not apply herbs, powders, or oils to the cord unless advised by a provider. Seek urgent care for fever, low temperature, yellow eyes, fast breathing, chest indrawing, convulsions, poor feeding, or unusual sleepiness.'),
('Hygiene','Infection prevention','Wash hands before breastfeeding, preparing food, changing pads, touching the cord, or handling baby items. Use clean pads and change them regularly after delivery. Keep wounds and stitches clean and return to the clinic for redness, pus, swelling, or increasing pain.'),
('Mental Health','Emotional support','Persistent sadness, fear, anxiety, hopelessness, or feeling disconnected from the baby deserves support. Talk to someone trusted and seek professional help if symptoms last more than two weeks or affect daily care. Urgent help is needed for thoughts of self-harm, harming the baby, confusion, or hearing or seeing things others do not.'),
('Family','Partner support','Partners and relatives can support clinic attendance, nutrition, transport, rest, emergency savings, household work, and newborn care. Families should agree on emergency contacts and decision making before labour starts, and should encourage qualified care when warning signs appear.'),
('Mobile Health','Digital reminders','Use phone reminders for ANC visits, supplements, medicines, immunizations, and postnatal checks. Keep clinic numbers, emergency contacts, and transport contacts saved. Digital advice should support, not replace, care from a qualified provider, and urgent symptoms should never wait for an online reply.'),
('Payments','Mobile money safety','Before approving mobile-money payments, confirm the merchant name, amount, phone number, order details, and delivery address. Keep transaction messages until the order or service is complete. Never share PINs, one-time codes, or account passwords. Report wrong transactions quickly.');
INSERT INTO orders (id, user_id, total_amount, status, delivery_address) VALUES
(1,2,63000,'confirmed','Mbezi Beach, Dar es Salaam'),(2,3,65000,'processing','Mwanza city center'),(3,4,52000,'delivered','Arusha Sokoni'),
(4,5,38000,'confirmed','Dodoma Area C'),(5,6,22000,'confirmed','Morogoro town'),(6,2,85000,'pending_payment','Kinondoni, Dar es Salaam'),
(7,3,72000,'delivered','Mbeya town'),(8,4,16000,'confirmed','Tanga CBD'),(9,5,145000,'processing','Kigoma Ujiji'),
(10,6,32000,'confirmed','Iringa town'),(11,2,9000,'delivered','Temeke, Dar es Salaam'),(12,3,45000,'confirmed','Moshi urban');

INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
(1,2,1,18000),(1,1,1,45000),(2,3,1,65000),(3,4,1,52000),(4,5,1,38000),(5,6,1,22000),
(6,7,1,85000),(7,8,1,72000),(8,9,1,16000),(9,10,1,145000),(10,11,1,32000),(11,12,1,9000);

INSERT INTO payments (order_id, user_id, method, phone, amount, status, transaction_reference, paid_at) VALUES
(1,2,'M-Pesa Sandbox','255700000002',63000,'paid','SIM-00001',NOW()),(2,3,'M-Pesa Sandbox','255700000003',65000,'paid','SIM-00002',NOW()),
(3,4,'M-Pesa Sandbox','255700000004',52000,'paid','SIM-00003',NOW()),(4,5,'M-Pesa Sandbox','255700000005',38000,'paid','SIM-00004',NOW()),
(5,6,'M-Pesa Sandbox','255700000006',22000,'paid','SIM-00005',NOW()),(6,2,'M-Pesa Sandbox','255700000002',85000,'otp_sent','SIM-00006',NULL),
(7,3,'M-Pesa Sandbox','255700000003',72000,'paid','SIM-00007',NOW()),(8,4,'M-Pesa Sandbox','255700000004',16000,'paid','SIM-00008',NOW()),
(9,5,'M-Pesa Sandbox','255700000005',145000,'paid','SIM-00009',NOW()),(10,6,'M-Pesa Sandbox','255700000006',32000,'paid','SIM-00010',NOW()),
(11,2,'M-Pesa Sandbox','255700000002',9000,'paid','SIM-00011',NOW()),(12,3,'M-Pesa Sandbox','255700000003',45000,'paid','SIM-00012',NOW());

INSERT INTO bookings (user_id, service_id, midwife_id, booking_date, booking_time, status, notes) VALUES
(2,1,7,'2026-06-02','09:00','confirmed','First trimester questions'),(3,2,8,'2026-06-03','10:30','pending','Nutrition and anemia'),
(4,3,9,'2026-06-04','11:00','completed','Delivery plan'),(5,4,7,'2026-06-05','14:00','confirmed','Postpartum pain'),
(6,5,8,'2026-06-06','15:30','pending','Breastfeeding help'),(2,6,9,'2026-06-07','08:30','confirmed','Newborn care'),
(3,7,7,'2026-06-08','12:00','pending','Referral concern'),(4,8,8,'2026-06-09','13:00','confirmed','Family planning'),
(5,9,9,'2026-06-10','16:00','pending','Young mother support'),(6,10,7,'2026-06-11','09:30','completed','ANC prep'),
(2,11,8,'2026-06-12','10:00','confirmed','Mood check'),(3,12,9,'2026-06-13','11:30','pending','Partner session');

INSERT INTO cart_items (user_id, product_id, quantity) VALUES
(2,3,1),(2,9,2),(3,1,1),(3,6,1),(4,2,2),(4,11,1),(5,5,1),(5,12,3),(6,4,1),(6,8,1),(2,10,1),(3,7,1);

INSERT INTO notifications (user_id, channel, subject, message, status) VALUES
(2,'sms','Order confirmed','MomCare order #1 confirmed.','sent'),(2,'email','Consultation booked','Your antenatal check-in is confirmed.','sent'),
(3,'sms','Payment received','M-Pesa sandbox payment received.','sent'),(3,'email','Booking pending','Your nutrition counselling request is pending.','sent'),
(4,'sms','Delivery update','Your order has been delivered.','sent'),(4,'email','Resource suggestion','Read danger sign guidance.','sent'),
(5,'sms','Order processing','Your safety item order is processing.','sent'),(5,'email','Appointment reminder','Your appointment is tomorrow.','sent'),
(6,'sms','OTP sent','Your sandbox payment PIN was sent.','sent'),(6,'email','Postpartum support','Your consultation request was recorded.','sent'),
(2,'sms','Cart reminder','You have items waiting in your cart.','sent'),(3,'email','Welcome','Welcome to MomCare.','sent');

INSERT INTO reviews (user_id, product_id, rating, comment) VALUES
(2,1,5,'Comfortable and clinic-friendly.'),(3,2,4,'Helpful supplement reminder on the label.'),(4,3,5,'The newborn pack saved time.'),
(5,4,4,'Good postpartum essentials.'),(6,5,5,'Very supportive for feeding.'),(2,6,4,'Useful hygiene pack.'),
(3,7,5,'Easy to use at home.'),(4,8,4,'Good delivery bag compartments.'),(5,9,5,'Affordable and filling.'),
(6,10,4,'Solid safety seat.'),(2,11,4,'Reduced back discomfort.'),(3,12,5,'Simple and practical guide.');

