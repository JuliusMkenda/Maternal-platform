<?php
declare(strict_types=1);

function create_notification(int $userId, string $channel, string $subject, string $message): void
{
    $stmt = db()->prepare('INSERT INTO notifications (user_id, channel, subject, message, status) VALUES (?, ?, ?, ?, "sent")');
    $stmt->execute([$userId, $channel, $subject, $message]);
}

function notify_order_confirmed(int $userId, int $orderId, string $phone, string $email): void
{
    $message = "MomCare order #{$orderId} confirmed. Payment verified for {$phone}.";
    create_notification($userId, 'sms', 'Order confirmed', $message);
    create_notification($userId, 'email', 'MomCare order confirmed', $message . " Confirmation also sent to {$email}.");
}

