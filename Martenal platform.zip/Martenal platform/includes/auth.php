<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $stmt = db()->prepare('SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function is_logged_in(): bool
{
    return current_user() !== null;
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        flash('error', 'Please sign in to continue.');
        redirect('login.php');
    }
    return $user;
}

function require_role(array $roles): array
{
    $user = require_login();
    if (!in_array($user['role_name'], $roles, true)) {
        render_access_denied('Access denied for this role.');
    }
    return $user;
}

function has_role(array $roles): bool
{
    $user = current_user();
    return $user !== null && in_array($user['role_name'], $roles, true);
}

function render_access_denied(string $message = 'Access denied for this role.'): never
{
    http_response_code(403);
    $title = 'Access Denied';
    include __DIR__ . '/../includes/header.php';
    ?>
    <div class="container py-5">
        <div class="alert alert-danger">
            <h1 class="h3">Access denied</h1>
            <p><?= e($message) ?></p>
            <a class="btn btn-outline-primary" href="index.php">Return to home</a>
        </div>
    </div>
    <?php
    include __DIR__ . '/../includes/footer.php';
    exit;
}

function login_user(string $email, string $password): bool
{
    $stmt = db()->prepare('SELECT * FROM users WHERE email = ? AND status = "active"');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $user['id'];
        return true;
    }

    return false;
}

function role_id(string $role): int
{
    $stmt = db()->prepare('SELECT id FROM roles WHERE name = ?');
    $stmt->execute([$role]);
    return (int) $stmt->fetchColumn();
}

