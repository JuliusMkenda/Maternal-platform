<?php
declare(strict_types=1);

function start_mpesa_simulation(int $orderId, string $phone, float $amount): string
{
    $otp = (string) random_int(100000, 999999);
    $_SESSION['mpesa'][$orderId] = [
        'phone' => $phone,
        'amount' => $amount,
        'otp_hash' => password_hash($otp, PASSWORD_DEFAULT),
        'created_at' => time(),
        'checkout_request_id' => 'SIM-' . strtoupper(bin2hex(random_bytes(5))),
        'development_otp' => $otp,
    ];
    return $otp;
}

function verify_mpesa_otp(int $orderId, string $otp): bool
{
    $payment = $_SESSION['mpesa'][$orderId] ?? null;
    if (!$payment || time() - (int) $payment['created_at'] > 600) {
        return false;
    }
    return password_verify($otp, $payment['otp_hash']);
}

