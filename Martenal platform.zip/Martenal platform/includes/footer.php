    </main>
    <footer class="footer-main py-5 mt-5">
        <div class="container">
            <div class="row g-4 align-items-center">
                <div class="col-lg-6">
                    <strong class="d-block h5 mb-2">MomCare Tanzania</strong>
                    <p class="mb-0">Maternal commerce, consultation, and care continuity in one trusted digital platform.</p>
                </div>
                <div class="col-lg-6 text-lg-end">
                    <span class="footer-pill me-2 mb-2"><i class="bi bi-phone"></i>M-Pesa ready</span>
                    <span class="footer-pill me-2 mb-2"><i class="bi bi-shield-check"></i>Secure sessions</span>
                    <span class="footer-pill mb-2"><i class="bi bi-heart-pulse"></i>Maternal care</span>
                </div>
            </div>
            <div class="border-top border-light border-opacity-10 mt-4 pt-3 d-flex flex-column flex-md-row justify-content-between gap-2 small">
                <span>&copy; <?= date('Y') ?> MomCare Tanzania</span>
                <span>Built for mothers, midwives, sellers, and care teams.</span>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/app.js"></script>
</body>
</html>
