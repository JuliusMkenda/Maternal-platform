<?php
declare(strict_types=1);

// Available languages
const AVAILABLE_LANGUAGES = ['en', 'sw', 'fr', 'es'];
const LANGUAGE_NAMES = [
    'en' => 'English',
    'sw' => 'Swahili',
    'fr' => 'Français',
    'es' => 'Español'
];

// Current language cache
$_TRANSLATION_CACHE = [];
$_CURRENT_LANGUAGE = null;

/**
 * Get current user language from database or session
 */
function get_current_language(): string
{
    global $_CURRENT_LANGUAGE;
    
    if ($_CURRENT_LANGUAGE) {
        return $_CURRENT_LANGUAGE;
    }
    
    // Check session
    if (isset($_SESSION['language']) && in_array($_SESSION['language'], AVAILABLE_LANGUAGES)) {
        $_CURRENT_LANGUAGE = $_SESSION['language'];
        return $_CURRENT_LANGUAGE;
    }
    
    // Check user preference in database
    $user = current_user();
    if ($user) {
        $stmt = db()->prepare('SELECT language FROM users WHERE id = ?');
        $stmt->execute([(int) $user['id']]);
        $result = $stmt->fetch();
        if ($result && in_array($result['language'], AVAILABLE_LANGUAGES)) {
            $_CURRENT_LANGUAGE = $result['language'];
            $_SESSION['language'] = $_CURRENT_LANGUAGE;
            return $_CURRENT_LANGUAGE;
        }
    }
    
    // Check browser language preference
    if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
        $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
        if (in_array($lang, AVAILABLE_LANGUAGES)) {
            $_CURRENT_LANGUAGE = $lang;
            $_SESSION['language'] = $_CURRENT_LANGUAGE;
            return $_CURRENT_LANGUAGE;
        }
    }
    
    // Default to English
    $_CURRENT_LANGUAGE = 'en';
    $_SESSION['language'] = 'en';
    return 'en';
}

/**
 * Load translation file for a language
 */
function load_language_file(string $lang): array
{
    global $_TRANSLATION_CACHE;
    
    if (isset($_TRANSLATION_CACHE[$lang])) {
        return $_TRANSLATION_CACHE[$lang];
    }
    
    if (!in_array($lang, AVAILABLE_LANGUAGES)) {
        $lang = 'en';
    }
    
    $file = __DIR__ . '/../languages/' . $lang . '.json';
    
    if (!file_exists($file)) {
        // Fallback to English if language file doesn't exist
        $file = __DIR__ . '/../languages/en.json';
    }
    
    $content = file_get_contents($file);
    $_TRANSLATION_CACHE[$lang] = json_decode($content, true) ?: [];
    
    return $_TRANSLATION_CACHE[$lang];
}

/**
 * Get a translated string
 * Usage: t('common.hello') or t('auth.login_button')
 */
function t(string $key, array $replacements = []): string
{
    $lang = get_current_language();
    $translations = load_language_file($lang);
    
    // Split the key by dot notation (e.g., 'common.hello')
    $keys = explode('.', $key);
    $value = $translations;
    
    foreach ($keys as $k) {
        if (is_array($value) && isset($value[$k])) {
            $value = $value[$k];
        } else {
            // Key not found, try English as fallback
            if ($lang !== 'en') {
                $en_translations = load_language_file('en');
                $value = $en_translations;
                foreach ($keys as $k) {
                    if (is_array($value) && isset($value[$k])) {
                        $value = $value[$k];
                    } else {
                        return $key; // Return the key if translation not found
                    }
                }
            } else {
                return $key;
            }
            break;
        }
    }
    
    // Replace placeholders if provided (e.g., {name} -> John)
    if (is_string($value) && !empty($replacements)) {
        foreach ($replacements as $placeholder => $replacement) {
            $value = str_replace('{' . $placeholder . '}', $replacement, $value);
        }
    }
    
    return is_string($value) ? $value : $key;
}

/**
 * Set user language preference
 */
function set_user_language(string $lang): bool
{
    global $_CURRENT_LANGUAGE;
    
    if (!in_array($lang, AVAILABLE_LANGUAGES)) {
        return false;
    }
    
    $_SESSION['language'] = $lang;
    $_CURRENT_LANGUAGE = $lang;
    
    $user = current_user();
    if ($user) {
        $stmt = db()->prepare('UPDATE users SET language = ? WHERE id = ?');
        $stmt->execute([$lang, (int) $user['id']]);
    }
    
    return true;
}

/**
 * Get all available languages with names
 */
function get_available_languages(): array
{
    $languages = [];
    foreach (AVAILABLE_LANGUAGES as $code) {
        $languages[$code] = LANGUAGE_NAMES[$code] ?? $code;
    }
    return $languages;
}

/**
 * Handle language change request (POST)
 * Should be called in bootstrap or early in page load
 */
function handle_language_change(): void
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_language'])) {
        $lang = $_POST['language'] ?? 'en';
        if (set_user_language($lang)) {
            // Redirect to same page with new language. Only redirect to the
            // referer if it is a valid URL on the same host as APP_URL to
            // avoid open-redirects and malformed Location headers.
            $referer = $_SERVER['HTTP_REFERER'] ?? '';
            if ($referer && filter_var($referer, FILTER_VALIDATE_URL)) {
                $refParts = parse_url($referer);
                $appParts = parse_url(APP_URL);
                $refHost = $refParts['host'] ?? '';
                $appHost = $appParts['host'] ?? '';
                if ($refHost !== '' && $appHost !== '' && strcasecmp($refHost, $appHost) === 0) {
                    redirect($referer);
                }
            }
            // Fallback: redirect to the site index
            redirect('index.php');
        }
    }
}
