<?php
declare(strict_types=1);

/**
 * Pregnancy tracking and notification helper functions
 */

/**
 * Get or create pregnancy progress for a user
 */
function get_pregnancy_progress(int $user_id): ?array
{
    $stmt = db()->prepare('SELECT * FROM pregnancy_progress WHERE user_id = ?');
    $stmt->execute([$user_id]);
    return $stmt->fetch() ?: null;
}

/**
 * Calculate pregnancy week and trimester
 */
function calculate_pregnancy_weeks(string $lmp_date): array
{
    $lmp = new DateTime($lmp_date);
    $today = new DateTime();
    $interval = $today->diff($lmp);
    $weeks = (int) ($interval->days / 7);
    
    $trimester = match (true) {
        $weeks < 13 => 1,
        $weeks < 27 => 2,
        default => 3,
    };
    
    $trimester_label = match ($trimester) {
        1 => '1st Trimester (Weeks 1-12)',
        2 => '2nd Trimester (Weeks 13-26)',
        3 => '3rd Trimester (Weeks 27-40)',
    };
    
    return [
        'weeks' => $weeks,
        'days' => $interval->days,
        'trimester' => $trimester,
        'trimester_label' => $trimester_label,
        'remaining_weeks' => max(0, 40 - $weeks),
    ];
}

/**
 * Get pregnancy milestones for a user
 */
function get_pregnancy_milestones(int $user_id): array
{
    $stmt = db()->prepare(
        'SELECT m.* FROM pregnancy_milestones m 
         JOIN pregnancy_progress p ON p.id = m.pregnancy_id 
         WHERE p.user_id = ? 
         ORDER BY m.milestone_date ASC'
    );
    $stmt->execute([$user_id]);
    return $stmt->fetchAll() ?: [];
}

/**
 * Get upcoming milestones (next 60 days)
 */
function get_upcoming_milestones(int $user_id): array
{
    $stmt = db()->prepare(
        'SELECT m.* FROM pregnancy_milestones m 
         JOIN pregnancy_progress p ON p.id = m.pregnancy_id 
         WHERE p.user_id = ? 
         AND m.milestone_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 60 DAY)
         AND m.is_completed = FALSE
         ORDER BY m.milestone_date ASC'
    );
    $stmt->execute([$user_id]);
    return $stmt->fetchAll() ?: [];
}

/**
 * Create a milestone notification
 */
function create_milestone_notification(int $user_id, string $title, string $message, string $category): void
{
    $stmt = db()->prepare(
        'INSERT INTO user_notifications (user_id, type, title, message) 
         VALUES (?, "milestone", ?, ?)'
    );
    $stmt->execute([$user_id, $title, $message]);
}

/**
 * Get unread notification count for a user
 */
function get_unread_notification_count(int $user_id): int
{
    $stmt = db()->prepare('SELECT COUNT(*) FROM user_notifications WHERE user_id = ? AND is_read = FALSE');
    $stmt->execute([$user_id]);
    return (int) $stmt->fetchColumn();
}

/**
 * Get recent notifications for a user (last 10)
 */
function get_user_notifications(int $user_id, int $limit = 10): array
{
    $stmt = db()->prepare(
        'SELECT * FROM user_notifications 
         WHERE user_id = ? 
         ORDER BY created_at DESC 
         LIMIT ?'
    );
    $stmt->execute([$user_id, $limit]);
    return $stmt->fetchAll() ?: [];
}

/**
 * Mark notification as read
 */
function mark_notification_read(int $notification_id): void
{
    $stmt = db()->prepare('UPDATE user_notifications SET is_read = TRUE WHERE id = ?');
    $stmt->execute([$notification_id]);
}

/**
 * Mark all notifications as read for a user
 */
function mark_all_notifications_read(int $user_id): void
{
    $stmt = db()->prepare('UPDATE user_notifications SET is_read = TRUE WHERE user_id = ? AND is_read = FALSE');
    $stmt->execute([$user_id]);
}

/**
 * Get notification preferences for a user
 */
function get_notification_preferences(int $user_id): array
{
    $stmt = db()->prepare('SELECT * FROM notification_preferences WHERE user_id = ?');
    $stmt->execute([$user_id]);
    $prefs = $stmt->fetch();
    
    if (!$prefs) {
        // Create default preferences
        $insert = db()->prepare(
            'INSERT INTO notification_preferences (user_id, notify_clinic_due, notify_new_products, notify_new_resources, notify_payment, notify_bookings, notify_milestones, preferred_channel) 
             VALUES (?, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, "both")'
        );
        $insert->execute([$user_id]);
        return get_notification_preferences($user_id);
    }
    
    return $prefs;
}

/**
 * Check if it's time to send milestone notifications
 */
function send_due_milestone_notifications(): void
{
    $today = date('Y-m-d');
    
    $stmt = db()->prepare(
        'SELECT m.*, p.user_id FROM pregnancy_milestones m 
         JOIN pregnancy_progress p ON p.id = m.pregnancy_id 
         WHERE m.milestone_date = ? AND m.notification_sent = FALSE'
    );
    $stmt->execute([$today]);
    $milestones = $stmt->fetchAll();
    
    foreach ($milestones as $milestone) {
        $prefs = get_notification_preferences((int) $milestone['user_id']);
        
        if ($prefs['notify_milestones']) {
            // Create the notification
            db()->prepare(
                'INSERT INTO user_notifications (user_id, type, title, message, related_id) 
                 VALUES (?, "milestone", ?, ?, ?)'
            )->execute([
                (int) $milestone['user_id'],
                $milestone['title'],
                $milestone['description'],
                (int) $milestone['id']
            ]);
            
            // Mark as sent
            db()->prepare('UPDATE pregnancy_milestones SET notification_sent = TRUE WHERE id = ?')
                ->execute([(int) $milestone['id']]);
        }
    }
}

/**
 * Get pregnancy statistics for dashboard
 */
function get_pregnancy_stats(int $user_id): array
{
    $progress = get_pregnancy_progress($user_id);
    
    if (!$progress) {
        return [
            'has_pregnancy' => false,
        ];
    }
    
    $calc = calculate_pregnancy_weeks($progress['last_menstrual_period']);
    $upcoming = get_upcoming_milestones($user_id);
    $unread_notifs = get_unread_notification_count($user_id);
    
    return [
        'has_pregnancy' => true,
        'weeks' => $calc['weeks'],
        'days' => $calc['days'],
        'trimester' => $calc['trimester'],
        'trimester_label' => $calc['trimester_label'],
        'remaining_weeks' => $calc['remaining_weeks'],
        'due_date' => $progress['expected_due_date'],
        'upcoming_milestones' => $upcoming,
        'next_milestone' => $upcoming[0] ?? null,
        'unread_notifications' => $unread_notifs,
    ];
}

/**
 * Format date for display
 */
function format_milestone_date(string $date): string
{
    return date('M d, Y', strtotime($date));
}

/**
 * Get milestone category icon
 */
function get_milestone_icon(string $category): string
{
    return match ($category) {
        'antenatal' => 'bi-hospital',
        'ultrasound' => 'bi-radar',
        'screening' => 'bi-shield-check',
        'delivery_prep' => 'bi-luggage',
        'postpartum' => 'bi-heart-pulse',
        default => 'bi-calendar',
    };
}

/**
 * Get milestone category color
 */
function get_milestone_color(string $category): string
{
    return match ($category) {
        'antenatal' => '#FF1493',
        'ultrasound' => '#FFB6C1',
        'screening' => '#FF69B4',
        'delivery_prep' => '#E91E63',
        'postpartum' => '#F06292',
        default => '#EC407A',
    };
}
