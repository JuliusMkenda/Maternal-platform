<?php
declare(strict_types=1);

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function money(float $amount): string
{
    return 'TZS ' . number_format($amount, 0);
}

function is_valid_phone(string $phone): bool
{
    return (bool) preg_match('/^2557[0-9]{8}$/', $phone);
}

function redirect(string $path): never
{
    // Allow passing either a relative path (e.g., 'products.php') or
    // an absolute URL (e.g., 'http://localhost/...'). If an absolute
    // URL is provided, use it directly. Otherwise, build a safe
    // absolute URL using APP_URL.
    if (filter_var($path, FILTER_VALIDATE_URL)) {
        header('Location: ' . $path);
    } else {
        header('Location: ' . rtrim(APP_URL, '/') . '/' . ltrim($path, '/'));
    }
    exit;
}

function flash(string $key, ?string $message = null): ?string
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }

    $value = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $value;
}

function post(string $key, string $default = ''): string
{
    return trim((string) ($_POST[$key] ?? $default));
}

function getv(string $key, string $default = ''): string
{
    return trim((string) ($_GET[$key] ?? $default));
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function verify_csrf(): void
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $sent = $_POST['csrf'] ?? '';
        if (!hash_equals($_SESSION['csrf'] ?? '', (string) $sent)) {
            http_response_code(403);
            exit('Invalid security token.');
        }
    }
}

function require_post_fields(array $fields): array
{
    $errors = [];
    foreach ($fields as $field) {
        if (post($field) === '') {
            $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required.';
        }
    }
    return $errors;
}

