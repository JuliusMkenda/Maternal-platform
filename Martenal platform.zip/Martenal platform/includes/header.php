<?php
$user = current_user();
$currentPage = basename($_SERVER['SCRIPT_NAME'] ?? '');
function nav_active(string $page, string $currentPage): string
{
    return $page === $currentPage ? ' active' : '';
}
?>
<!doctype html>
<html lang="<?= e(get_current_language()) ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? APP_NAME) ?> - <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800;900&family=Playfair+Display:wght@600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css?v=2" rel="stylesheet">
    <?php if (defined('GOOGLE_PLACES_API_KEY') && GOOGLE_PLACES_API_KEY !== ''): ?>
        <!-- Google Places API will be loaded dynamically from checkout.php when needed -->
    <?php endif; ?>
</head>
<body>
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php" aria-label="MomCare home">
            <span class="brand-mark"><i class="bi bi-heart-pulse-fill"></i></span>
            <span>MomCare</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
                <li class="nav-item"><a class="nav-link<?= nav_active('products.php', $currentPage) ?>" href="products.php"><i class="bi bi-bag-heart me-1"></i><?= t('products') ?></a></li>
                <li class="nav-item"><a class="nav-link<?= nav_active('services.php', $currentPage) ?>" href="services.php"><i class="bi bi-calendar2-heart me-1"></i><?= t('services') ?></a></li>
                <li class="nav-item"><a class="nav-link<?= nav_active('resources.php', $currentPage) ?>" href="resources.php"><i class="bi bi-journal-medical me-1"></i><?= t('resources') ?></a></li>
                <li class="nav-item"><a class="nav-link<?= nav_active('cart.php', $currentPage) ?>" href="cart.php"><i class="bi bi-cart3 me-1"></i><?= t('cart') ?></a></li>
                <li class="nav-item"><a class="nav-link<?= nav_active('orders.php', $currentPage) ?>" href="orders.php"><i class="bi bi-receipt me-1"></i><?= t('orders') ?></a></li>
                <?php if ($user): ?>
                    <li class="nav-item"><a class="nav-link<?= str_contains($currentPage, 'dashboard') ? ' active' : '' ?>" href="dashboard.php"><i class="bi bi-speedometer2 me-1"></i><?= t('dashboard') ?></a></li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav align-items-lg-center gap-lg-2">
                <?php if ($user): ?>
                    <?php $unread_count = get_unread_notification_count((int) $user['id']); ?>
                    <li class="nav-item position-relative">
                        <a class="nav-link" href="notifications.php" title="Notifications">
                            <i class="bi bi-bell"></i>
                            <?php if ($unread_count > 0): ?>
                                <span class="badge bg-danger position-absolute top-0 start-100 translate-middle-x">
                                    <?= min($unread_count, 9) . ($unread_count > 9 ? '+' : '') ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item"><span class="nav-link"><i class="bi bi-person-circle me-1"></i><?= e($user['full_name']) ?></span></li>
                    <li class="nav-item"><a class="btn btn-light btn-sm" href="logout.php"><i class="bi bi-box-arrow-right"></i><?= t('logout') ?></a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link<?= nav_active('login.php', $currentPage) ?>" href="login.php"><?= t('login') ?></a></li>
                    <li class="nav-item"><a class="btn btn-light btn-sm" href="register.php"><i class="bi bi-person-plus"></i><?= t('register') ?></a></li>
                <?php endif; ?>
                <li class="nav-item">
                    <form method="post" class="d-inline" id="langForm">
                        <input type="hidden" name="change_language" value="1">
                        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                        <select name="language" class="form-select form-select-sm" onchange="document.getElementById('langForm').submit();" style="width: auto; display: inline-block;">
                            <?php foreach (get_available_languages() as $code => $name): ?>
                                <option value="<?= $code ?>" <?= get_current_language() === $code ? 'selected' : '' ?>>
                                    <?= $name ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>
<main>
    <div class="container py-3">
        <?php if ($message = flash('success')): ?>
            <div class="alert alert-success"><i class="bi bi-check-circle-fill me-2"></i><?= e($message) ?></div>
        <?php endif; ?>
        <?php if ($message = flash('error')): ?>
            <div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= e($message) ?></div>
        <?php endif; ?>
    </div>

