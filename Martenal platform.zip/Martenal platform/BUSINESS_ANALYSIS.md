# MomCare Business Analysis Component

## A.i Problem Statement Analysis and Validation

Pregnant and postpartum women in Tanzania often face delayed access to maternal products, trusted health information, and professional support. The challenge is stronger in peri-urban and rural settings where transport costs, facility distance, stock shortages, and limited specialist availability affect timely care seeking.

Evidence supporting the problem:

- The World Bank Gender Data Portal reports that Tanzania's maternal mortality ratio improved from 980 deaths per 100,000 live births in 2000 to 276 in 2023, but this is still far above the SDG target of fewer than 70 deaths per 100,000 live births by 2030.
- The World Bank World Development Indicators list Tanzania at 98% for pregnant women receiving prenatal care in the 2018-2023 period, but only 64% of births were attended by skilled health staff in the 2016-2021 period. This shows that awareness and first contact exist, while continuity, delivery support, and timely service linkage still need strengthening.
- Tanzania DHS-MIS 2022 maternal care indicators track skilled antenatal care, four or more ANC visits, iron supplementation, skilled delivery, facility delivery, and postnatal checks in the first two days after birth. These are exactly the points where reminders, product access, referral education, and remote consultation can support continuity.
- Tanzania's digital payment environment is strong enough for a mobile-first maternal commerce model. Reported 2024 mobile-money activity shows active subscriptions above 63 million and growth in transaction value, while TCRA-linked reporting shows M-Pesa, Airtel Money, and Mixx by Yas dominate the market.

MomCare responds by combining maternal e-commerce, appointment booking, education, order tracking, and digital notifications in one platform.

Sources used for validation:

- World Bank Gender Data Portal, Tanzania maternal mortality profile: https://genderdata.worldbank.org/en/economies/tanzania
- World Bank World Development Indicators, maternal and reproductive health table: https://wdi.worldbank.org/table/2.14
- Tanzania DHS-MIS 2022 Key Indicators Report: https://www.nbs.go.tz/nbs/takwimu/dhs/2022-TDHS-MIS-Key-Indicators-Report.pdf
- Tanzania mobile-money market reporting based on TCRA/Bank of Tanzania statistics: https://www.tanzaniainvest.com/finance/banking/mobile-money-transactions-virtual-card-registrations-2024

## A.ii Target Market and Personas

Primary market:

- Pregnant women.
- New mothers.
- Families buying maternal and newborn care products.

Secondary market:

- Licensed midwives, nurses, doulas, lactation consultants, and nutrition advisors.
- Maternal product sellers, pharmacies, clinics, and baby-care retailers.
- NGOs and health programs that need maternal outreach channels.

Personas:

1. Amina, first-time mother in Dar es Salaam  
   Needs affordable maternity kits, reminders, reliable product information, and easy mobile payment.

2. Neema, professional midwife  
   Needs a way to receive bookings, manage consultations, and follow up with mothers digitally.

3. Mamasafe Supplies, maternal product seller  
   Needs online visibility, order management, product performance statistics, and customer trust.

4. Clinic admin  
   Needs oversight of users, services, orders, bookings, revenue, and notification records.

## A.iii E-Commerce Strategy and Digital Business Model

MomCare uses a multi-sided platform model:

- Product marketplace: Sellers list maternal and newborn products.
- Service marketplace: Midwives and consultants offer booked consultations.
- Content and resource hub: Users access maternal health articles and support information.
- Digital payment layer: M-Pesa sandbox simulation supports mobile checkout readiness.
- Notification layer: Email/SMS-style confirmations improve trust and follow-up.

Core digital workflow:

1. User registers by role.
2. Customer browses products or services.
3. Customer adds products to cart or books a consultant.
4. Customer checks out using simulated M-Pesa.
5. System records order/payment and sends confirmation notifications.
6. Admin, seller, and midwife dashboards track operational activity.

## A.iv Competitive Analysis and Differentiation

Existing alternatives include general marketplaces, pharmacies, maternal clinics, WhatsApp sellers, and standalone health information sites. These solutions are useful but usually separate commerce, consultation, maternal education, and order follow-up.

MomCare differentiation:

- Maternal-health-specific marketplace rather than a general shop.
- Three operational dashboards: mother/customer, consultant/midwife, seller, plus admin.
- Combined product purchase and consultation booking.
- Local mobile-money-first checkout flow.
- Structured records for future care history and operational analytics.
- Health-resource section designed around pregnancy and postpartum needs.

## A.v Revenue and Monetization Strategy

Revenue streams:

- Product commission per completed order.
- Seller subscription for premium listing and analytics.
- Consultation commission per successful booking.
- Sponsored maternal health campaigns from clinics, NGOs, or product brands.
- Featured products and promoted seller placement.
- Institutional dashboard licensing for clinics or maternal health programs.

Key metrics:

- Registered mothers.
- Monthly active users.
- Completed orders.
- Consultation booking conversion.
- Average order value.
- Repeat purchase rate.
- Seller revenue.
- Booking attendance rate.
- Notification delivery success.
