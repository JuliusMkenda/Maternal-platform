# Project Report & Analysis — MomCare Platform

Date: 2026-06-20

## 1. Languages (programming & human)
- Programming / technical languages used:
  - PHP (backend, templates)
  - JavaScript (frontend interactions, fetch calls)
  - HTML / CSS (presentation) — Bootstrap used
  - SQL (MySQL schema and seed files)
  - Python (small tooling: `tools/generate_translation_report.py`)

- Human languages supported (UI translations):
  - English (`languages/en.json`)
  - Swahili (`languages/sw.json`)
  - French (`languages/fr.json`)
  - Spanish (`languages/es.json`)

## 2. Databases and their function
- Primary physical database: `maternal_db` (configured in `config/config.php` as `DB_NAME`).
  - Created/seeded by: `database/maternal_db.sql`.
  - Purpose: single unified relational database for the platform storing users, roles, products, services, orders, payments, bookings, notifications, reviews, and supporting data.

- Additional schema / feature migrations (add tables into the same `maternal_db`):
  - `database/pregnancy_tracking.sql` — pregnancy tracking features:
    - `pregnancy_progress`, `pregnancy_milestones`, `notification_preferences`, `user_notifications`.
    - Adds richer notification, milestone, and preference data for maternal care features.
  - `database/calendar_events.sql` and `database/calendar_events_seed.sql` — calendar feature:
    - `calendar_events` table and demo events for users.

- Summary (logical databases/tables):
  - Roles & Users — authentication/authorization and profile data.
  - Marketplace — `categories`, `products`, `reviews`, `cart_items`.
  - Orders & Payments — `orders`, `order_items`, `payments` (escrow/payout columns included).
  - Services & Bookings — `services`, `bookings` (midwife consultations etc.).
  - Resources & Content — `resources` (educational materials).
  - Notifications & Calendar — `notifications`, `user_notifications`, `calendar_events`.

> Note: there is one deployed DB (`maternal_db`) but multiple SQL files create/augment its schema.

## 3. External APIs and external integrations
- Address / place search:
  - Google Places API — optional primary provider (key in `config/config.php` environment var `GOOGLE_PLACES_API_KEY`).
  - Mapbox — optional (key `MAPBOX_API_KEY`) used in some address/autocomplete flows.
  - OpenStreetMap Nominatim — used as free fallback via server proxy `public/nominatim.php` to avoid CORS.

- Payments:
  - M-Pesa (mobile-money) — simulated sandbox implementation in `includes/mpesa.php` and used by checkout/payment flow (OTP simulation, store in `payments` table). Production integration would use Safaricom APIs and credentials in config (placeholders exist for consumer key/secret/shortcode/passkey).

- Other external endpoints:
  - Unsplash-hosted image URLs are used for seeded product images (public CDN links only).
  - No direct SMTP / SMS gateway is integrated in the repo — notifications are stored and prepared (`notifications` table) but delivery drivers are not wired to third-party SMS/email APIs in the codebase.

## 4. Platform parties and UML diagrams

High-level parties / actors:
- Customer (mother) — browses catalog, adds to cart, checks out, books services, receives notifications, tracks pregnancy data.
- Seller — lists products, manages product status and inventory via seller dashboard.
- Midwife/Consultant — lists/maintains services, receives bookings, provides consultations.
- Admin — manages users/products/orders, runs site-wide tasks.

Relationships (ER / component view):

```mermaid
erDiagram
    USERS ||--o{ ORDERS : places
    USERS ||--o{ BOOKINGS : books
    USERS ||--o{ CART_ITEMS : owns
    USERS ||--o{ NOTIFICATIONS : receives
    USERS ||--o{ PAYMENTS : makes
    USERS ||--o{ REVIEWS : writes

    ROLES ||--o{ USERS : assigns

    PRODUCTS }|..|{ CATEGORIES : categorized
    PRODUCTS ||--o{ ORDER_ITEMS : included_in
    PRODUCTS ||--o{ REVIEWS : receives
    PRODUCTS }o--|| USERS : sold_by

    SERVICES }o--|| USERS : provided_by_midwife
    BOOKINGS ||--|| SERVICES : for
    BOOKINGS }o--|| USERS : with_midwife

    ORDERS ||--o{ ORDER_ITEMS : contains
    ORDERS ||--o{ PAYMENTS : paid_by
    PAYMENTS }o--|| ORDERS : references

    CALENDAR_EVENTS }o--|| USERS : belongs_to

```

Sequence (checkout -> payment -> notifications):

```mermaid
sequenceDiagram
    participant C as Customer
    participant S as Server (PHP)
    participant DB as Database
    participant MP as M-Pesa (Sandbox)
    participant N as Notification subsystem

    C->>S: Submit checkout (cart, address, mpesa_phone)
    S->>DB: Create order, order_items, payments(status=otp_sent)
    S->>MP: start_mpesa_simulation(orderId, phone, amount)
    MP-->>S: simulated OTP generated (stored in session)
    S->>C: show OTP screen
    C->>S: Submit OTP
    S->>MP: verify_mpesa_otp(orderId, otp)
    MP-->>S: verification result
    alt success
        S->>DB: update payment status = paid; update order status
        S->>N: create notifications (sms/email queued)
        S->>C: show confirmation
    else failure
        S->>C: show failure
    end
```

## 5. E‑commerce strategies implemented
- Marketplace model (multi-seller): products include `seller_id` linking to users with seller role; sellers can manage inventory and product status.
- Cart & Checkout: standard cart model (`cart_items`) and order lifecycle (`orders`, `order_items`).
- Mobile money-first payments (M‑Pesa): platform models OTP flow, payment statuses, escrow and payout columns in `payments` to support escrow-like flows and delayed payouts to sellers.
- Escrow-like states: `payments` contains `escrow_status` and `payout_status` to support holding funds while order is processed and releasing to sellers later.
- Service marketplace + bookings: midwives provide paid services that can be booked and scheduled (bookings table).
- Notifications & reminders: database-driven notifications (`notifications`, `user_notifications`) for booking, payment, and milestone alerts — enables later integration with SMS/email providers.
- Reviews & trust signals: product reviews table and sample reviews help buyer confidence.
- Localization & accessibility: UI translation system with JSON language files and a language selector supports English/Swahili/French/Spanish for broader reach.
- Address-autocomplete & geocoding: improves checkout accuracy and captures lat/lng to support delivery; dual-provider strategy (Google primary, Nominatim fallback).

## 6. Recommendations & next steps
- Production payment integration: replace sandbox `includes/mpesa.php` with Safaricom Lipa na M-Pesa or other provider; implement secure server-to-server callbacks.
- Notifications: integrate an SMS gateway (e.g., Twilio, Africa's Talking) and an SMTP provider for email delivery; add retries and logging.
- Translation workflow: add a small admin tool to export `strings_for_translation.json` and re-import translated JSON files; optionally integrate with a translation API or TMS.
- Monitoring & rate limits: protect Nominatim proxy with rate limiting and caching. Prefer a paid provider for heavy address autocomplete usage.
- Security: ensure API keys are read from environment, enforce HTTPS for production, and add monitoring on payment and critical flows.

---

If you want, I can:
- generate downloadable UML PNGs (via Mermaid render) and add them to the repo;
- produce a shorter executive summary; or
- add the admin translation export/import tool described in the recommendations.
