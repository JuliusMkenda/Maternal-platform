<?php
require_once __DIR__ . '/_bootstrap.php';
$title = t('home.title');
include __DIR__ . '/../includes/header.php';

$stats = [
    'products' => (int) db()->query('SELECT COUNT(*) FROM products WHERE status = "active"')->fetchColumn(),
    'services' => (int) db()->query('SELECT COUNT(*) FROM services WHERE status = "active"')->fetchColumn(),
    'orders' => (int) db()->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
];
$featured = db()->query('SELECT p.*, c.name AS category FROM products p JOIN categories c ON c.id = p.category_id WHERE p.status = "active" ORDER BY p.id DESC LIMIT 3')->fetchAll();
?>
<section class="hero">
    <div class="hero-bg" data-images='[
        "https://images.unsplash.com/photo-1584515933487-779824d29309?auto=format&fit=crop&w=1800&q=85",
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1800&q=85",
        "https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1800&q=85"
    ]'></div>
    <div class="container py-5">
        <div class="col-lg-8">
            <span class="hero-kicker"><i class="bi bi-heart-pulse-fill"></i> <?= t('Maternal care platform') ?></span>
            <h1 class="fw-black"><?= t('Care for you, Care for baby') ?></h1>
            <p class="lead animated-pink fallback-visible"><?= t('Your trusted partner for a healthy pregnancy, happy baby and confident motherhood') ?></p>
            <div class="d-flex flex-wrap gap-2 mt-4">
                <a class="btn btn-light btn-lg" href="products.php"><i class="bi bi-bag-heart"></i><?= t('Shop now') ?></a>
                <a class="btn btn-outline-light btn-lg" href="services.php"><i class="bi bi-calendar2-heart"></i><?= t('Book consultation now') ?></a>
            </div>
            <div class="hero-panel">
                <div class="hero-chip"><strong><?= $stats['products'] ?>+</strong><span><?= t('Products') ?></span></div>
                <div class="hero-chip"><strong><?= $stats['services'] ?>+</strong><span><?= t('Services') ?></span></div>
                <div class="hero-chip"><strong><?= $stats['orders'] ?>+</strong><span><?= t('Orders') ?></span></div>
            </div>
        </div>
    </div>
</section>
<section class="container feature-strip pb-5">
    <div class="row g-3">
        <div class="col-md-4">
            <div class="feature-card">
                <span class="feature-icon"><i class="bi bi-bag-check"></i></span>
                <h2 class="h5"><?= t('Quality products available') ?></h2>
                <p class="mb-0 text-secondary"><?= t('Platform offer a wide range of high-quality maternal and infant products') ?></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feature-card">
                <span class="feature-icon"><i class="bi bi-person-heart"></i></span>
                <h2 class="h5"><?= t('Professional midwives available') ?></h2>
                <p class="mb-0 text-secondary"><?= t('We have a team of experienced and qualified midwives available for consultation and support') ?></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feature-card">
                <span class="feature-icon"><i class="bi bi-phone-vibrate"></i></span>
                <h2 class="h5"><?= t('Secure payment processing') ?></h2>
                <p class="mb-0 text-secondary"><?= t('All transactions are processed securely with industry-standard encryption') ?></p>
            </div>
        </div>
    </div>
</section>
<section class="container pb-5">
    <div class="section-title mb-4">
        <span class="eyebrow"><?= t('Services offered') ?></span>
        <h2 class="h3 mt-2"><?= t('') ?></h2>
    </div>
    <div class="row g-3">
        <div class="col-md-4"><div class="metric"><strong><?= $stats['products'] ?></strong><span>Quality maternal products available</span></div></div>
        <div class="col-md-4"><div class="metric"><strong><?= $stats['services'] ?></strong><span>Consultation services listed</span></div></div>
        <div class="col-md-4"><div class="metric"><strong><?= $stats['orders'] ?></strong><span>Orders recorded in database with efficiency</span></div></div>
    </div>
</section>
<section class="page-band py-5">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-4">
                <div class="section-title">
                <span class="eyebrow"><?= t('Featured Products') ?></span>
                <h2 class="h3 mt-2 mb-0"><?= t('') ?></h2>
            </div>
            <a class="btn btn-outline-success" href="products.php"><i class="bi bi-grid"></i><?= t('view all products') ?></a>
        </div>
        <div class="row g-4">
            <?php foreach ($featured as $product): ?>
                <div class="col-md-4">
                    <div class="card h-100">
                        <img class="card-img-top product-img" src="<?= e($product['image_url']) ?>" alt="<?= e($product['name']) ?>">
                        <div class="card-body">
                            <span class="badge bg-success-subtle text-success"><?= e($product['category']) ?></span>
                            <h3 class="h5 mt-3"><?= e($product['name']) ?></h3>
                            <p class="text-secondary"><?= e($product['short_description']) ?></p>
                            <strong class="fs-5"><?= money((float) $product['price']) ?></strong>
                        </div>
                        <div class="card-footer bg-white"><a class="btn btn-success w-100" href="product.php?id=<?= (int) $product['id'] ?>"><i class="bi bi-arrow-right-circle"></i><?= t('Product details') ?></a></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<section class="container py-5">
    <div class="row g-4 align-items-stretch">
        <div class="col-lg-6">
            <div class="card card-body h-100">
                <span class="feature-icon"><i class="bi bi-speedometer2"></i></span>
                <h2 class="h4">Role-based dashboards</h2>
                <p class="text-secondary">Customers track orders and bookings, midwives manage appointments, sellers add products, and admins monitor the platform.</p>
                <a class="btn btn-outline-success align-self-start" href="dashboard.php">Open Dashboard</a>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card card-body h-100">
                <span class="feature-icon"><i class="bi bi-journal-medical"></i></span>
                <h2 class="h4">Maternal resources</h2>
                <p class="text-secondary">Access short health guidance on antenatal care, danger signs, nutrition, postpartum checks, breastfeeding, and newborn care.</p>
                <a class="btn btn-outline-success align-self-start" href="resources.php">Read Resources</a>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>
