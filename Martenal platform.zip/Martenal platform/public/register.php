<?php
require_once __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = require_post_fields(['full_name', 'email', 'phone', 'password', 'role']);
    $role = post('role');
    if (!filter_var(post('email'), FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email is required.';
    }
    if (!is_valid_phone(post('phone'))) {
        $errors[] = 'Enter a valid Vodacom phone number in the format 2557XXXXXXXX.';
    }
    if (!in_array($role, ['customer', 'midwife', 'seller'], true)) {
        $errors[] = 'Choose a valid account type.';
    }
    if (strlen(post('password')) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    }

    if (!$errors) {
        $stmt = db()->prepare('SELECT COUNT(*) FROM users WHERE email = ? OR phone = ?');
        $stmt->execute([post('email'), post('phone')]);
        if ((int) $stmt->fetchColumn() > 0) {
            $errors[] = 'Email or phone already exists.';
        }
    }

    if (!$errors) {
        $stmt = db()->prepare('INSERT INTO users (role_id, full_name, email, phone, password_hash, status) VALUES (?, ?, ?, ?, ?, "active")');
        $stmt->execute([role_id($role), post('full_name'), post('email'), post('phone'), password_hash(post('password'), PASSWORD_DEFAULT)]);
        flash('success', 'Account created. Please sign in.');
        redirect('login.php');
    }
}

$title = t('auth.register_title');
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <div class="row justify-content-center">
?>
        <div class="col-lg-7">
            <h1 class="h3 mb-3">Create Account</h1>
            <?php foreach ($errors ?? [] as $error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endforeach; ?>
            <form class="card card-body" method="post">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <div class="row g-3">
                    <div class="col-md-6"><label class="form-label"><?= t('Full Name') ?></label><input class="form-control" name="full_name" required></div>
                    <div class="col-md-6"><label class="form-label"><?= t('Phone number') ?></label><input class="form-control" type="tel" name="phone" placeholder="+2557XXXXXXXX" pattern="+2557[0-9]{8}" title="<?= t('auth.phone_help') ?>" required></div>
                    <div class="col-md-6"><label class="form-label"><?= t('Email') ?></label><input class="form-control" type="email" name="email" required></div>
                    <div class="col-md-6"><label class="form-label"><?= t('Password') ?></label><input class="form-control" type="password" name="password" required></div>
                    <div class="col-12">
                        <label class="form-label"><?= t('Account Type') ?></label>
                        <select class="form-select" name="role" required>
                            <option value="customer"><?= t('Customer/Maternal') ?></option>
                            <option value="midwife"><?= t('Midwife') ?></option>
                            <option value="seller"><?= t('Seller') ?></option>
                        </select>
                    </div>
                    <div class="col-12"><button class="btn btn-success"><?= t('Register') ?></button></div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

