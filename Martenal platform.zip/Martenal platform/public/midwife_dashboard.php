<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['midwife']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingId = (int) post('booking_id');
    $status = in_array(post('status'), ['pending', 'confirmed', 'completed', 'cancelled'], true) ? post('status') : 'pending';
    $stmt = db()->prepare('UPDATE bookings SET status = ? WHERE id = ? AND midwife_id = ?');
    $stmt->execute([$status, $bookingId, (int) $user['id']]);
    flash('success', 'Booking status updated.');
    redirect('midwife_dashboard.php');
}

$bookings = db()->prepare('SELECT b.*, s.name AS service_name, u.full_name AS customer FROM bookings b JOIN services s ON s.id = b.service_id JOIN users u ON u.id = b.user_id WHERE b.midwife_id = ? ORDER BY b.booking_date DESC');
$bookings->execute([(int) $user['id']]);
$services = db()->prepare('SELECT * FROM services WHERE midwife_id = ? ORDER BY name');
$services->execute([(int) $user['id']]);

$title = 'Midwife Dashboard';
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <h1 class="h3 mb-3">Midwife / Consultant Dashboard</h1>
    <div class="row g-4">
        <div class="col-lg-8">
            <h2 class="h5">Appointments</h2>
            <div class="table-responsive"><table class="table mb-0">
                <thead><tr><th>Mother</th><th>Service</th><th>Date</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                <?php foreach ($bookings as $booking): ?>
                    <tr>
                        <td><?= e($booking['customer']) ?></td><td><?= e($booking['service_name']) ?></td><td><?= e($booking['booking_date']) ?> <?= e($booking['booking_time']) ?></td>
                        <td><?= e($booking['status']) ?></td>
                        <td>
                            <form method="post" class="d-flex gap-1">
                                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                                <input type="hidden" name="booking_id" value="<?= (int) $booking['id'] ?>">
                                <select class="form-select form-select-sm" name="status"><option>confirmed</option><option>completed</option><option>cancelled</option></select>
                                <button class="btn btn-sm btn-success">Save</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
        </div>
        <div class="col-lg-4">
            <h2 class="h5">My Services</h2>
            <?php foreach ($services as $service): ?>
                <div class="card card-body mb-2"><strong><?= e($service['name']) ?></strong><span><?= money((float) $service['price']) ?></span></div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

