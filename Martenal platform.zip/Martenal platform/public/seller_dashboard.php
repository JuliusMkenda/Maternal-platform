<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['seller']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($deleteProductId = post('delete_product_id')) {
        $stmt = db()->prepare('DELETE FROM products WHERE id = ? AND seller_id = ?');
        $stmt->execute([(int) $deleteProductId, (int) $user['id']]);
        flash('success', 'Product removed.');
        redirect('seller_dashboard.php');
    }

    if ($noteOrderItemId = post('note_order_item_id')) {
        $stmt = db()->prepare('UPDATE order_items oi JOIN products p ON p.id = oi.product_id SET oi.seller_notes = ? WHERE oi.id = ? AND p.seller_id = ?');
        $stmt->execute([post('seller_note'), (int) $noteOrderItemId, (int) $user['id']]);
        flash('success', 'Seller note saved.');
        redirect('seller_dashboard.php');
    }

    $errors = require_post_fields(['category_id', 'name', 'price', 'stock_quantity']);
    if (!$errors) {
        $stmt = db()->prepare('INSERT INTO products (seller_id, category_id, name, short_description, description, price, stock_quantity, image_url, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, "active")');
        $stmt->execute([(int) $user['id'], (int) post('category_id'), post('name'), post('short_description'), post('description'), (float) post('price'), (int) post('stock_quantity'), post('image_url', 'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?auto=format&fit=crop&w=900&q=80')]);
        flash('success', 'Product added.');
        redirect('seller_dashboard.php');
    }
}

$categories = db()->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$products = db()->prepare('SELECT p.*, c.name AS category FROM products p JOIN categories c ON c.id = p.category_id WHERE seller_id = ? ORDER BY p.id DESC');
$products->execute([(int) $user['id']]);
$sales = db()->prepare('SELECT oi.*, p.name, o.status, pay.payout_status, pay.payout_date FROM order_items oi JOIN products p ON p.id = oi.product_id JOIN orders o ON o.id = oi.order_id LEFT JOIN payments pay ON pay.order_id = o.id WHERE p.seller_id = ? ORDER BY oi.id DESC LIMIT 12');
$sales->execute([(int) $user['id']]);

$title = 'Seller Dashboard';
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <h1 class="h3 mb-3">Product Seller Dashboard</h1>
    <div class="row g-4">
        <div class="col-lg-5">
            <h2 class="h5">Add Product</h2>
            <?php foreach ($errors ?? [] as $error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endforeach; ?>
            <form class="card card-body" method="post">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <select class="form-select mb-2" name="category_id"><?php foreach ($categories as $cat): ?><option value="<?= (int) $cat['id'] ?>"><?= e($cat['name']) ?></option><?php endforeach; ?></select>
                <input class="form-control mb-2" name="name" placeholder="Product name" required>
                <input class="form-control mb-2" name="short_description" placeholder="Short description">
                <textarea class="form-control mb-2" name="description" placeholder="Description"></textarea>
                <input class="form-control mb-2" type="number" name="price" placeholder="Price" required>
                <input class="form-control mb-2" type="number" name="stock_quantity" placeholder="Stock" required>
                <input class="form-control mb-2" name="image_url" placeholder="Image URL">
                <button class="btn btn-success">Save Product</button>
            </form>
        </div>
        <div class="col-lg-7">
            <h2 class="h5">My Products</h2>
            <div class="table-responsive"><table class="table mb-0"><thead><tr><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Action</th></tr></thead><tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?= e($product['name']) ?></td>
                        <td><?= e($product['category']) ?></td>
                        <td><?= money((float) $product['price']) ?></td>
                        <td><?= (int) $product['stock_quantity'] ?></td>
                        <td>
                            <form method="post" class="d-inline">
                                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                                <input type="hidden" name="delete_product_id" value="<?= (int) $product['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Remove this product?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody></table></div>
            <h2 class="h5 mt-4">Recent Sales</h2>
            <div class="table-responsive"><table class="table mb-0">
                <thead><tr><th>Product</th><th>Qty</th><th>Order</th><th>Payout</th><th>Note</th><th>Order #</th></tr></thead>
                <tbody>
                <?php foreach ($sales as $sale): ?>
                    <tr>
                        <td><?= e($sale['name']) ?></td>
                        <td><?= (int) $sale['quantity'] ?></td>
                        <td><?= e($sale['status']) ?></td>
                        <td>
                            <strong><?= e($sale['payout_status'] ?? 'pending') ?></strong>
                            <?php if (!empty($sale['payout_date'])): ?><div class="text-muted small"><?= e($sale['payout_date']) ?></div><?php endif; ?>
                        </td>
                        <td style="min-width:200px;">
                            <form method="post">
                                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                                <input type="hidden" name="note_order_item_id" value="<?= (int) $sale['id'] ?>">
                                <div class="mb-2">
                                    <textarea class="form-control form-control-sm" name="seller_note" rows="2" placeholder="Reconciliation note"><?= e($sale['seller_notes'] ?? '') ?></textarea>
                                </div>
                                <button class="btn btn-sm btn-primary">Save</button>
                            </form>
                        </td>
                        <td><span class="text-muted small">#<?= (int) $sale['order_id'] ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody></table></div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

