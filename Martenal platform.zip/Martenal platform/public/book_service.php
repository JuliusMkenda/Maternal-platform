<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['customer']);
$id = (int) getv('id', '0');
$stmt = db()->prepare('SELECT s.*, u.full_name AS consultant FROM services s JOIN users u ON u.id = s.midwife_id WHERE s.id = ?');
$stmt->execute([$id]);
$service = $stmt->fetch();
if (!$service) {
    http_response_code(404);
    exit('Service not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = require_post_fields(['booking_date', 'booking_time']);
    if (!DateTime::createFromFormat('Y-m-d', post('booking_date')) || post('booking_date') < date('Y-m-d')) {
        $errors[] = 'Choose a valid future booking date.';
    }
    if (!preg_match('/^[0-2][0-9]:[0-5][0-9]$/', post('booking_time'))) {
        $errors[] = 'Enter a valid booking time.';
    }

    if (!$errors) {
        $stmt = db()->prepare('INSERT INTO bookings (user_id, service_id, midwife_id, booking_date, booking_time, status, notes) VALUES (?, ?, ?, ?, ?, "pending", ?)');
        $stmt->execute([(int) $user['id'], $id, (int) $service['midwife_id'], post('booking_date'), post('booking_time'), post('notes')]);
        create_notification((int) $user['id'], 'email', 'Consultation booked', 'Your MomCare consultation request has been recorded.');
        flash('success', 'Consultation booking request sent.');
        redirect('dashboard.php');
    }
}

$title = 'Book Service';
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <h1 class="h3 mb-3">Book <?= e($service['name']) ?></h1>
    <form class="card card-body" method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <p>Consultant: <?= e($service['consultant']) ?> · Price: <?= money((float) $service['price']) ?></p>
        <div class="row g-3">
            <div class="col-md-6"><label class="form-label">Date</label><input class="form-control" type="date" name="booking_date" required></div>
            <div class="col-md-6"><label class="form-label">Time</label><input class="form-control" type="time" name="booking_time" required></div>
            <div class="col-12"><label class="form-label">Notes</label><textarea class="form-control" name="notes"></textarea></div>
            <div class="col-12"><button class="btn btn-success">Request Booking</button></div>
        </div>
    </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

