<?php
require_once __DIR__ . '/_bootstrap.php';

$services = db()->query('SELECT s.*, u.full_name AS consultant FROM services s JOIN users u ON u.id = s.midwife_id WHERE s.status = "active" ORDER BY s.name')->fetchAll();
$title = t('services.title');
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <h1 class="h3 mb-3"><?= t('Booking services') ?></h1>
    <div class="row g-4">
        <?php foreach ($services as $service): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h2 class="h5"><?= e($service['name']) ?></h2>
                        <p><?= e($service['description']) ?></p>
                        <p><strong><?= money((float) $service['price']) ?></strong> · <?= (int) $service['duration_minutes'] ?> <?= t('minutes duration services') ?></p>
                        <p><?= t('services consultant') ?>: <?= e($service['consultant']) ?></p>
                    </div>
                    <div class="card-footer bg-white">
                        <?php if (has_role(['customer'])): ?>
                            <a class="btn btn-success w-100" href="book_service.php?id=<?= (int) $service['id'] ?>"><?= t('Book service now') ?></a>
                        <?php else: ?>
                            <span class="text-muted"><?= t('book services') ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

