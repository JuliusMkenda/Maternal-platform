<?php
require_once __DIR__ . '/_bootstrap.php';

$search = getv('q');
$category = getv('category');
$max = getv('max');
$categories = db()->query('SELECT * FROM categories ORDER BY name')->fetchAll();

$sql = 'SELECT p.*, c.name AS category FROM products p JOIN categories c ON c.id = p.category_id WHERE p.status = "active"';
$params = [];
if ($search !== '') {
    $sql .= ' AND (p.name LIKE ? OR p.short_description LIKE ?)';
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}
if ($category !== '') {
    $sql .= ' AND c.slug = ?';
    $params[] = $category;
}
if ($max !== '' && is_numeric($max)) {
    $sql .= ' AND p.price <= ?';
    $params[] = (float) $max;
}
$sql .= ' ORDER BY p.name';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$title = t('products.title');
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <h1 class="h3 mb-3"><?= t('products') ?></h1>
    <form class="card card-body mb-4" method="get">
        <div class="row g-2">
            <div class="col-md-4"><input class="form-control" name="q" value="<?= e($search) ?>" placeholder="<?= t('search') ?>"></div>
            <div class="col-md-3">
                <select class="form-select" name="category">
                    <option value=""><?= t('categories') ?></option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= e($cat['slug']) ?>" <?= $category === $cat['slug'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3"><input class="form-control" type="number" name="max" value="<?= e($max) ?>" placeholder="<?= t('price') ?>"></div>
            <div class="col-md-2"><button class="btn btn-success w-100"><?= t('filter products') ?></button></div>
        </div>
    </form>
    <div class="row g-4">
        <?php foreach ($products as $product): ?>
            <div class="col-sm-6 col-lg-4">
                <div class="card h-100">
                    <img class="card-img-top product-img" src="<?= e($product['image_url']) ?>" alt="<?= e($product['name']) ?>">
                    <div class="card-body">
                        <span class="badge bg-success-subtle text-success"><?= e($product['category']) ?></span>
                        <h2 class="h5 mt-2"><?= e($product['name']) ?></h2>
                        <p><?= e($product['short_description']) ?></p>
                        <strong><?= money((float) $product['price']) ?></strong>
                    </div>
                    <div class="card-footer bg-white"><a class="btn btn-outline-success w-100" href="product.php?id=<?= (int) $product['id'] ?>"><?= t('products details') ?></a></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

