<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'httponly' => true,
    'samesite' => 'Lax',
    'secure' => str_starts_with(APP_URL, 'https://'),
]);
session_start();

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/translations.php';
verify_csrf();
handle_language_change();
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/../includes/notifications.php';
require_once __DIR__ . '/../includes/pregnancy_tracking.php';
require_once __DIR__ . '/../includes/mpesa.php';
 
