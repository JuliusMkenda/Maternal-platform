<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['customer']);

$stmt = db()->prepare('SELECT ci.*, p.price, p.stock_quantity FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.user_id = ?');
$stmt->execute([(int) $user['id']]);
$items = $stmt->fetchAll();
$noItemsMessage = t('Cart is empty');
if (!$items) {
    flash('error', $noItemsMessage);
    redirect('products.php');
}
$total = array_reduce($items, fn($sum, $item) => $sum + ((float) $item['price'] * (int) $item['quantity']), 0.0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = require_post_fields(['delivery_address', 'mpesa_phone']);
    if (!is_valid_phone(post('mpesa_phone'))) {
        $errors[] = t('Sorry the entered M-Pesa phone number is invalid');
    }
    if (post('delivery_address') === '') {
        $errors[] = t('Delivery address required');
    }

    foreach ($items as $item) {
        if ((int) $item['quantity'] > (int) $item['stock_quantity']) {
            $errors[] = t('Sorry, there is insufficient stock for {name}', ['name' => e($item['name'])]);
            break;
        }
    }

    $deliveryLat = post('delivery_lat');
    $deliveryLng = post('delivery_lng');
    if ($deliveryLat !== '' && $deliveryLng !== '') {
        if (!is_numeric($deliveryLat) || !is_numeric($deliveryLng)) {
            $errors[] = t('Selected delivery location is invalid.');
        }
    } else {
        $deliveryLat = null;
        $deliveryLng = null;
    }

    if (!$errors) {
        db()->beginTransaction();
        $stmt = db()->prepare('INSERT INTO orders (user_id, total_amount, status, delivery_address, delivery_lat, delivery_lng) VALUES (?, ?, "pending_payment", ?, ?, ?)');
        $stmt->execute([(int) $user['id'], $total, post('delivery_address'), $deliveryLat, $deliveryLng]);
        $orderId = (int) db()->lastInsertId();

        foreach ($items as $item) {
            $line = db()->prepare('INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)');
            $line->execute([$orderId, (int) $item['product_id'], (int) $item['quantity'], (float) $item['price']]);
        }

        $otp = start_mpesa_simulation($orderId, post('mpesa_phone'), $total);
        $payment = $_SESSION['mpesa'][$orderId];
        $stmt = db()->prepare('INSERT INTO payments (order_id, user_id, method, phone, amount, status, transaction_reference, payout_status) VALUES (?, ?, "M-Pesa Sandbox", ?, ?, "otp_sent", ?, "pending")');
        $stmt->execute([$orderId, (int) $user['id'], post('mpesa_phone'), $total, $payment['checkout_request_id']]);
        create_notification((int) $user['id'], 'sms', 'M-Pesa OTP sent', "Your MomCare sandbox OTP is {$otp} for order #{$orderId}.");
        db()->commit();
        redirect('payment.php?order=' . $orderId);
    }
}

$title = t('common.checkout');
include __DIR__ . '/../includes/header.php';
?>
<div class="checkout-hero">
    <div class="hero-bg" data-images='[
        "https://images.unsplash.com/photo-1584515933487-779824d29309?auto=format&fit=crop&w=1800&q=85",
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1800&q=85",
        "https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1800&q=85",
        "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1800&q=85",
        "https://images.unsplash.com/photo-1542362567-b07e54358753?auto=format&fit=crop&w=1800&q=85"
    ]' data-interval="7000"></div>
    <div class="container checkout-content pb-5">
        <h1 class="h3 mb-3"><?= t('Checkout') ?></h1>
    <?php foreach ($errors ?? [] as $error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endforeach; ?>
    <div class="row g-4">
        <div class="col-lg-7">
            <form class="card card-body" method="post" autocomplete="off">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                
                <!-- Address Autocomplete Section -->
                <div class="mb-3">
                    <label class="form-label fw-bold"><?= t('Delivery address') ?></label>
                    <div class="position-relative">
                        <input 
                            id="delivery_address" 
                            class="form-control" 
                            name="delivery_address" 
                            placeholder="<?= t('Delivery address placeholder') ?>" 
                            value="<?= e(post('delivery_address') ?? '') ?>" 
                            autocomplete="off"
                            required
                        >
                        <div id="autocomplete_dropdown" class="autocomplete-dropdown" style="display: none;">
                            <div id="autocomplete_results" class="autocomplete-results"></div>
                        </div>
                    </div>
                    <small class="text-muted d-block mt-2"><?= t('Checkout address help') ?></small>
                </div>

                <!-- Address Details (auto-populated from selection) -->
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label text-muted small">City</label>
                        <input id="delivery_city" class="form-control form-control-sm" placeholder="Auto-filled" readonly>
                    </div>
                </div>

                <!-- Hidden coordinates -->
                <input type="hidden" name="delivery_lat" id="delivery_lat" value="<?= e(post('delivery_lat') ?? '') ?>">
                <input type="hidden" name="delivery_lng" id="delivery_lng" value="<?= e(post('delivery_lng') ?? '') ?>">

                <!-- Phone Section -->
                <div class="payment-brand mb-4">
                    <img src="../images/mpesa-logo.svg" alt="M-Pesa logo">
                    <div class="payment-brand-text">
                        <span class="payment-brand-title">Pay with M-Pesa</span>
                        <span class="payment-brand-note">Use your M-Pesa phone number to receive the payment PIN.</span>
                    </div>
                </div>
                <label class="form-label fw-bold mt-4"><?= t('M-Pesa Phone') ?></label>
                <input class="form-control mb-3" type="tel" name="mpesa_phone" placeholder="+2557XXXXXXXX" pattern="+2557[0-9]{8}" title="<?= t('Enter valid M-Pesa phone number') ?>" value="<?= e(post('mpesa_phone') ?? '') ?>" required>
                <div class="text-muted small mb-3"><?= t('Valid M-Pesa phone number') ?></div>

                <button class="btn btn-success btn-lg w-100"><?= t('Send M-Pesa PIN') ?></button>
            </form>

            <style>
                .autocomplete-dropdown {
                    position: absolute;
                    top: 100%;
                    left: 0;
                    right: 0;
                    background: white;
                    border: 1px solid #dee2e6;
                    border-top: none;
                    border-radius: 0 0 0.375rem 0.375rem;
                    max-height: 400px;
                    overflow-y: auto;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                    z-index: 1000;
                }
                
                .autocomplete-results {
                    padding: 0;
                }
                
                .autocomplete-result {
                    padding: 12px 16px;
                    cursor: pointer;
                    border-bottom: 1px solid #f0f0f0;
                    transition: background-color 0.2s ease;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .autocomplete-result:last-child {
                    border-bottom: none;
                }
                
                .autocomplete-result:hover,
                .autocomplete-result.active {
                    background-color: #f8f9fa;
                }
                
                .autocomplete-result-main {
                    flex: 1;
                }
                
                .autocomplete-result-address {
                    font-weight: 500;
                    color: #212529;
                    font-size: 0.95rem;
                }
                
                .autocomplete-result-secondary {
                    font-size: 0.85rem;
                    color: #6c757d;
                    margin-top: 3px;
                }
                
                .autocomplete-result-icon {
                    margin-left: 10px;
                    color: #0d6efd;
                    font-size: 1.1rem;
                }
                
                .autocomplete-loading {
                    padding: 12px 16px;
                    text-align: center;
                    color: #6c757d;
                }
                
                .autocomplete-error {
                    padding: 12px 16px;
                    color: #dc3545;
                    text-align: center;
                    font-size: 0.9rem;
                }
            </style>

            <script>
                (function () {
                    const addressInput = document.getElementById('delivery_address');
                    const dropdown = document.getElementById('autocomplete_dropdown');
                    const resultsContainer = document.getElementById('autocomplete_results');
                    const cityInput = document.getElementById('delivery_city');
                    const latInput = document.getElementById('delivery_lat');
                    const lngInput = document.getElementById('delivery_lng');

                    let currentResults = [];
                    let activeIndex = -1;
                    let currentRequest = null;
                    let sessionToken = generateUUID();

                    // Generate UUID for session token (Google Places requirement)
                    function generateUUID() {
                        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                            const r = Math.random() * 16 | 0;
                            const v = c === 'x' ? r : (r & 0x3 | 0x8);
                            return v.toString(16);
                        });
                    }

                    // Debounce utility
                    function debounce(fn, delay) {
                        let timer;
                        return function (...args) {
                            clearTimeout(timer);
                            timer = setTimeout(() => fn.apply(this, args), delay);
                        };
                    }

                    // Parse address components from Google Places response
                    function parseAddressComponents(place) {
                        let city = '';

                        if (place.address_components) {
                            place.address_components.forEach(component => {
                                const types = component.types || [];
                                if (types.includes('locality')) {
                                    city = component.long_name;
                                }
                            });
                        }

                        return { city };
                    }

                    // Fetch suggestions from Google Places API
                    function fetchSuggestions(query) {
                        if (!query || query.length < 2) {
                            dropdown.style.display = 'none';
                            return;
                        }

                        if (currentRequest) currentRequest.abort();
                        currentRequest = new AbortController();

                        resultsContainer.innerHTML = '<div class="autocomplete-loading"><small>Searching...</small></div>';
                        dropdown.style.display = 'block';

                        // Check if Google Places is available
                        if (window.google && google.maps && google.maps.places) {
                            fetchGooglePlaces(query);
                        } else {
                            // Fallback to server proxy
                            fetchNominatim(query);
                        }
                    }

                    // Google Places Autocomplete Service
                    function fetchGooglePlaces(query) {
                        const service = new google.maps.places.AutocompleteService();
                        service.getPlacePredictions(
                            {
                                input: query,
                                sessionToken: sessionToken,
                                types: ['geocode'],
                                componentRestrictions: { country: ['tz'] } // Tanzania - adjust as needed
                            },
                            (predictions, status) => {
                                if (status !== 'OK') {
                                    resultsContainer.innerHTML = '<div class="autocomplete-error">No results found</div>';
                                    currentResults = [];
                                    return;
                                }

                                currentResults = predictions || [];
                                renderGoogleResults(predictions || []);
                            }
                        );
                    }

                    // Render Google Places results
                    function renderGoogleResults(predictions) {
                        resultsContainer.innerHTML = '';

                        if (predictions.length === 0) {
                            resultsContainer.innerHTML = '<div class="autocomplete-error">No locations found</div>';
                            return;
                        }

                        predictions.forEach((prediction, idx) => {
                            const item = document.createElement('div');
                            item.className = 'autocomplete-result';
                            item.setAttribute('data-index', idx);
                            item.innerHTML = `
                                <div class="autocomplete-result-main">
                                    <div class="autocomplete-result-address">${escapeHtml(prediction.main_text)}</div>
                                    <div class="autocomplete-result-secondary">${escapeHtml(prediction.secondary_text)}</div>
                                </div>
                                <div class="autocomplete-result-icon">
                                    <i class="bi bi-geo-alt-fill"></i>
                                </div>
                            `;
                            item.addEventListener('click', () => selectGooglePlace(prediction, idx));
                            item.addEventListener('mouseenter', () => setActive(idx));
                            resultsContainer.appendChild(item);
                        });

                        activeIndex = -1;
                    }

                    // Select a Google Place prediction
                    function selectGooglePlace(prediction, idx) {
                        const placeService = new google.maps.places.PlacesService(
                            document.createElement('div')
                        );

                        resultsContainer.innerHTML = '<div class="autocomplete-loading"><small>Loading...</small></div>';

                        placeService.getDetails(
                            {
                                placeId: prediction.place_id,
                                sessionToken: sessionToken,
                                fields: [
                                    'formatted_address',
                                    'geometry',
                                    'address_components',
                                    'name'
                                ]
                            },
                            (place, status) => {
                                if (status !== 'OK') {
                                    console.error('PlacesService error:', status);
                                    return;
                                }

                                const { city } = parseAddressComponents(place);
                                const displayAddress = place.formatted_address || prediction.main_text;
                                const lat = place.geometry?.location?.lat() || '';
                                const lng = place.geometry?.location?.lng() || '';

                                populateAddress(displayAddress, city, lat, lng);
                                dropdown.style.display = 'none';
                                sessionToken = generateUUID(); // Reset token after place selected
                            }
                        );
                    }

                    // Fallback to Nominatim (OpenStreetMap)
                    function fetchNominatim(query) {
                        fetch('nominatim.php?q=' + encodeURIComponent(query) + '&limit=6', {
                            signal: currentRequest.signal,
                            headers: { 'Accept-Language': 'en' }
                        })
                            .then(r => r.json())
                            .then(results => renderNominatimResults(results))
                            .catch(err => {
                                if (err.name !== 'AbortError') {
                                    console.error('Error fetching suggestions:', err);
                                    resultsContainer.innerHTML = '<div class="autocomplete-error">Error loading suggestions</div>';
                                }
                            });
                    }

                    // Render Nominatim results
                    function renderNominatimResults(results) {
                        resultsContainer.innerHTML = '';

                        if (!results || results.length === 0) {
                            resultsContainer.innerHTML = '<div class="autocomplete-error">No locations found</div>';
                            currentResults = [];
                            return;
                        }

                        currentResults = results;

                        results.forEach((result, idx) => {
                            const addressParts = (result.display_name || '').split(',').slice(0, 2);
                            const mainAddress = addressParts[0] || '';
                            const secondary = addressParts.slice(1).join(',').trim();

                            const item = document.createElement('div');
                            item.className = 'autocomplete-result';
                            item.setAttribute('data-index', idx);
                            item.innerHTML = `
                                <div class="autocomplete-result-main">
                                    <div class="autocomplete-result-address">${escapeHtml(mainAddress)}</div>
                                    <div class="autocomplete-result-secondary">${escapeHtml(secondary)}</div>
                                </div>
                                <div class="autocomplete-result-icon">
                                    <i class="bi bi-geo-alt-fill"></i>
                                </div>
                            `;
                            item.addEventListener('click', () => selectNominatimPlace(result, idx));
                            item.addEventListener('mouseenter', () => setActive(idx));
                            resultsContainer.appendChild(item);
                        });

                        activeIndex = -1;
                    }

                    // Select a Nominatim result
                    function selectNominatimPlace(result, idx) {
                        const address = result.display_name || '';
                        const city = result.address?.city || result.address?.town || '';
                        const lat = result.lat || '';
                        const lng = result.lon || '';

                        populateAddress(address, city, lat, lng);
                        dropdown.style.display = 'none';
                    }

                    // Populate address fields
                    function populateAddress(address, city, lat, lng) {
                        addressInput.value = address;
                        cityInput.value = city || '';
                        latInput.value = lat || '';
                        lngInput.value = lng || '';
                    }

                    // Set active result
                    function setActive(idx) {
                        document.querySelectorAll('.autocomplete-result').forEach(el => {
                            el.classList.remove('active');
                        });
                        activeIndex = idx;
                        const active = document.querySelector(`[data-index="${idx}"]`);
                        if (active) active.classList.add('active');
                    }

                    // Escape HTML
                    function escapeHtml(text) {
                        const map = {
                            '&': '&amp;',
                            '<': '&lt;',
                            '>': '&gt;',
                            '"': '&quot;',
                            "'": '&#039;'
                        };
                        return text.replace(/[&<>"']/g, m => map[m]);
                    }

                    // Event listeners
                    const debouncedFetch = debounce(fetchSuggestions, 300);
                    addressInput.addEventListener('input', () => {
                        latInput.value = '';
                        lngInput.value = '';
                        cityInput.value = '';
                        debouncedFetch(addressInput.value.trim());
                    });

                    addressInput.addEventListener('keydown', (e) => {
                        const items = resultsContainer.querySelectorAll('.autocomplete-result');

                        if (e.key === 'ArrowDown') {
                            e.preventDefault();
                            if (items.length === 0) return;
                            activeIndex = Math.min(activeIndex + 1, items.length - 1);
                            setActive(activeIndex);
                        } else if (e.key === 'ArrowUp') {
                            e.preventDefault();
                            if (items.length === 0) return;
                            activeIndex = Math.max(activeIndex - 1, -1);
                            if (activeIndex >= 0) setActive(activeIndex);
                            else {
                                document.querySelectorAll('.autocomplete-result').forEach(el => el.classList.remove('active'));
                            }
                        } else if (e.key === 'Enter') {
                            e.preventDefault();
                            if (activeIndex >= 0) {
                                const item = items[activeIndex];
                                item?.click();
                            }
                        } else if (e.key === 'Escape') {
                            dropdown.style.display = 'none';
                        }
                    });

                    // Close on outside click
                    document.addEventListener('click', (e) => {
                        if (e.target !== addressInput && !dropdown.contains(e.target)) {
                            dropdown.style.display = 'none';
                        }
                    });

                    // Inject Google Places script if key is available
                    const googleKey = '<?= defined("GOOGLE_PLACES_API_KEY") ? e(GOOGLE_PLACES_API_KEY) : "" ?>';
                    if (googleKey) {
                        const script = document.createElement('script');
                        script.src = 'https://maps.googleapis.com/maps/api/js?key=' + googleKey + '&libraries=places&language=en';
                        script.async = true;
                        script.defer = true;
                        document.head.appendChild(script);
                    }
                })();
            </script>
        </div>
        <div class="col-lg-5">
            <div class="card card-body">
                <h2 class="h5">Order Summary</h2>
                <p><?= count($items) ?> cart lines</p>
                <strong><?= money($total) ?></strong>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

