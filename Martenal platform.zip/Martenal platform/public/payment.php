<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['customer']);
$orderId = (int) getv('order', '0');

$stmt = db()->prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?');
$stmt->execute([$orderId, (int) $user['id']]);
$order = $stmt->fetch();
if (!$order) {
    http_response_code(404);
    exit('Order not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verify_mpesa_otp($orderId, post('otp'))) {
        $checkoutRequestId = $_SESSION['mpesa'][$orderId]['checkout_request_id'] ?? null;
        db()->beginTransaction();
        db()->prepare('UPDATE orders SET status = "escrow_hold" WHERE id = ?')->execute([$orderId]);
        db()->prepare('UPDATE payments SET status = "paid", method = "Admin Escrow Account", escrow_status = "held", paid_at = NOW(), transaction_reference = ? WHERE order_id = ?')->execute([$checkoutRequestId ? 'ADMIN-' . $checkoutRequestId : 'ADMIN-' . time(), $orderId]);
        db()->prepare('UPDATE products p JOIN order_items oi ON oi.product_id = p.id SET p.stock_quantity = p.stock_quantity - oi.quantity WHERE oi.order_id = ?')->execute([$orderId]);
        db()->prepare('DELETE FROM cart_items WHERE user_id = ?')->execute([(int) $user['id']]);
        notify_order_confirmed((int) $user['id'], $orderId, $_SESSION['mpesa'][$orderId]['phone'], $user['email']);
        db()->commit();
        unset($_SESSION['mpesa'][$orderId]);
        flash('success', 'Payment verified and recorded as issued to admin escrow account.');
        redirect('order_confirmation.php?order=' . $orderId);
    }
    flash('error', 'Invalid OTP. Please try again.');
    redirect('payment.php?order=' . $orderId);
}

$devOtp = $_SESSION['mpesa'][$orderId]['development_otp'] ?? 'Not available';
$title = 'Payment Verification';
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="payment-brand mb-4">
                <img src="../images/mpesa-logo.svg" alt="M-Pesa logo">
                <div class="payment-brand-text">
                    <span class="payment-brand-title">M-Pesa Sandbox Verification</span>
                    <span class="payment-brand-note">Confirm your payment using the OTP sent to your M-Pesa phone.</span>
                </div>
            </div>
            <h1 class="h3 mb-3">M-Pesa Sandbox Verification</h1>
            <div class="alert alert-info">Development sandbox PIN: <strong><?= e($devOtp) ?></strong></div>
            <form class="card card-body" method="post">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <label class="form-label">Enter phone PIN/OTP</label>
                <input class="form-control mb-3" name="otp" maxlength="6" required>
                <button class="btn btn-success">Confirm Payment</button>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

