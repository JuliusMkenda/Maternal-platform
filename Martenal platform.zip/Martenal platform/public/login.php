<?php
require_once __DIR__ . '/_bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (login_user(post('email'), post('password'))) {
        redirect('dashboard.php');
    }
    flash('error', t('messages.error_occurred') . ': ' . t('auth.login_required'));
}

$title = t('login_title');
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <h1 class="h3 mb-3"><?= t('login') ?></h1>
            <form class="card card-body" method="post">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <label class="form-label"><?= t('email') ?></label>
                <input class="form-control mb-3" type="email" name="email" required>
                <label class="form-label"><?= t('password') ?></label>
                <input class="form-control mb-3" type="password" name="password" required>
                <button class="btn btn-success"><?= t('login') ?></button>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

