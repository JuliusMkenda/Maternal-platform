<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_login();

$target = match ($user['role_name']) {
    'admin' => 'admin_dashboard.php',
    'seller' => 'seller_dashboard.php',
    'midwife' => 'midwife_dashboard.php',
    default => 'customer_dashboard.php',
};
redirect($target);

