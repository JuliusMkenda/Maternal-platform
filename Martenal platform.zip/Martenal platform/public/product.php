<?php
require_once __DIR__ . '/_bootstrap.php';

$id = (int) getv('id', '0');
$stmt = db()->prepare('SELECT p.*, c.name AS category, u.full_name AS seller FROM products p JOIN categories c ON c.id = p.category_id JOIN users u ON u.id = p.seller_id WHERE p.id = ?');
$stmt->execute([$id]);
$product = $stmt->fetch();
if (!$product) {
    http_response_code(404);
    exit(t('products not found'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = require_role(['customer']);
    $qty = max(1, (int) post('quantity', '1'));
    if ($qty > (int) $product['stock_quantity']) {
        flash('error', t('Quantity exceeds'));
    } else {
        $stmt = db()->prepare('INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)');
        $stmt->execute([(int) $user['id'], $id, $qty]);
        flash('success', t('Item added to cart'));
        redirect('cart.php');
    }
}

$reviews = db()->prepare('SELECT r.*, u.full_name FROM reviews r JOIN users u ON u.id = r.user_id WHERE product_id = ? ORDER BY r.id DESC');
$reviews->execute([$id]);

$title = $product['name'];
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <div class="row g-4">
        <div class="col-md-5"><img class="img-fluid rounded border" src="<?= e($product['image_url']) ?>" alt="<?= e($product['name']) ?>"></div>
        <div class="col-md-7">
            <span class="badge bg-success"><?= e($product['category']) ?></span>
            <h1 class="h2 mt-2"><?= e($product['name']) ?></h1>
            <p><?= e($product['description']) ?></p>
            <p><strong><?= money((float) $product['price']) ?></strong> · <?= t('stock') ?>: <?= (int) $product['stock_quantity'] ?> · <?= t('seller') ?>: <?= e($product['seller']) ?></p>
            <?php if (has_role(['customer'])): ?>
                <form method="post" class="d-flex gap-2">
                    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                    <input class="form-control" style="max-width:120px" type="number" min="1" name="quantity" value="1">
                    <button class="btn btn-success"><?= t('add_to_cart') ?></button>
                </form>
            <?php else: ?>
                <div class="alert alert-info mb-0"><?= t('products login to add') ?></div>
            <?php endif; ?>
        </div>
    </div>
    <h2 class="h4 mt-5">Reviews</h2>
    <?php foreach ($reviews as $review): ?>
        <div class="border-bottom py-2"><strong><?= e($review['full_name']) ?></strong> rated <?= (int) $review['rating'] ?>/5<br><?= e($review['comment']) ?></div>
    <?php endforeach; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

