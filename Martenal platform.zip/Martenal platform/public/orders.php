<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_login();

if ($user['role_name'] === 'admin') {
    $stmt = db()->query('SELECT o.*, u.full_name, p.escrow_status, p.escrow_released_at FROM orders o JOIN users u ON u.id = o.user_id LEFT JOIN payments p ON p.order_id = o.id ORDER BY o.id DESC');
} else {
    $stmt = db()->prepare('SELECT o.*, u.full_name, p.escrow_status, p.escrow_released_at FROM orders o JOIN users u ON u.id = o.user_id LEFT JOIN payments p ON p.order_id = o.id WHERE o.user_id = ? ORDER BY o.id DESC');
    $stmt->execute([(int) $user['id']]);
}
$orders = $stmt->fetchAll();

$title = t('orders.title');
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <h1 class="h3 mb-3"><?= t('orders') ?></h1>
    <div class="table-responsive">
        <table class="table mb-0">
            <thead><tr><th>#</th><th><?= t('customer') ?></th><th><?= t('total') ?></th><th><?= t('status') ?></th><th><?= t('date') ?></th><?php if ($user['role_name'] === 'customer'): ?><th><?= t('action') ?></th><?php endif; ?></tr></thead>
            <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?= (int) $order['id'] ?></td>
                    <td><?= e($order['full_name']) ?></td>
                    <td><?= money((float) $order['total_amount']) ?></td>
                    <td>
                        <?= e($order['status']) ?>
                        <?php if (!empty($order['escrow_status']) && $order['escrow_status'] !== 'released'): ?>
                            <small class="text-muted d-block"><?= e($order['escrow_status']) ?><?php if ($order['escrow_status'] === 'release_scheduled' && !empty($order['escrow_released_at'])): ?> until <?= e($order['escrow_released_at']) ?><?php endif; ?></small>
                        <?php elseif ($order['escrow_status'] === 'released'): ?>
                            <small class="text-success d-block"><?= t('escrow_released') ?></small>
                        <?php endif; ?>
                    </td>
                    <td><?= e($order['created_at']) ?></td>
                    <?php if ($user['role_name'] === 'customer'): ?>
                        <td>
                            <?php if ($order['status'] === 'escrow_hold'): ?>
                                    <a class="btn btn-sm btn-outline-success" href="order_confirmation.php?order=<?= (int) $order['id'] ?>"><?= t('confirm_receipt') ?></a>
                                <?php else: ?>
                                    <span class="text-muted"><?= t('no_actions') ?></span>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

