<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['admin']);

$metrics = [
    'users' => (int) db()->query('SELECT COUNT(*) FROM users')->fetchColumn(),
    'orders' => (int) db()->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'revenue' => (float) db()->query('SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status = "paid"')->fetchColumn(),
    'bookings' => (int) db()->query('SELECT COUNT(*) FROM bookings')->fetchColumn(),
];
$users = db()->query('SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id ORDER BY u.id DESC LIMIT 12')->fetchAll();
$orders = db()->query('SELECT o.*, u.full_name FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.id DESC LIMIT 12')->fetchAll();
$products = db()->query('SELECT p.*, c.name AS category FROM products p JOIN categories c ON c.id = p.category_id ORDER BY p.id DESC LIMIT 12')->fetchAll();

$title = 'Admin Dashboard';
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3 mb-0">Admin Dashboard</h1>
        <a class="btn btn-success" href="admin_manage.php">Manage Records</a>
    </div>
    <div class="row g-3 mb-4">
        <div class="col-md-3"><div class="metric"><strong><?= $metrics['users'] ?></strong><span>Users</span></div></div>
        <div class="col-md-3"><div class="metric"><strong><?= $metrics['orders'] ?></strong><span>Orders</span></div></div>
        <div class="col-md-3"><div class="metric"><strong><?= money($metrics['revenue']) ?></strong><span>Paid revenue</span></div></div>
        <div class="col-md-3"><div class="metric"><strong><?= $metrics['bookings'] ?></strong><span>Bookings</span></div></div>
    </div>
    <div class="row g-4">
        <div class="col-lg-6"><h2 class="h5">Users</h2><div class="table-responsive"><table class="table mb-0"><tbody>
            <?php foreach ($users as $row): ?><tr><td><?= e($row['full_name']) ?></td><td><?= e($row['role_name']) ?></td><td><?= e($row['status']) ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div>
        <div class="col-lg-6"><h2 class="h5">Orders</h2><div class="table-responsive"><table class="table mb-0"><tbody>
            <?php foreach ($orders as $row): ?><tr><td>#<?= (int) $row['id'] ?></td><td><?= e($row['full_name']) ?></td><td><?= money((float) $row['total_amount']) ?></td><td><?= e($row['status']) ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div>
        <div class="col-12"><h2 class="h5">Products</h2><div class="table-responsive"><table class="table mb-0"><tbody>
            <?php foreach ($products as $row): ?><tr><td><?= e($row['name']) ?></td><td><?= e($row['category']) ?></td><td><?= money((float) $row['price']) ?></td><td><?= (int) $row['stock_quantity'] ?> stock</td></tr><?php endforeach; ?>
        </tbody></table></div></div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
