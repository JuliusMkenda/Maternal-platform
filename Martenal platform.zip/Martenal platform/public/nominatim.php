<?php
declare(strict_types=1);

// Simple proxy to Nominatim to avoid browser CORS issues.
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config/config.php';

$q = (string) ($_GET['q'] ?? '');
$limit = (int) ($_GET['limit'] ?? 5);
if ($q === '') {
    echo json_encode([]);
    exit;
}

$url = 'https://nominatim.openstreetmap.org/search?format=json&limit=' . $limit . '&addressdetails=1&q=' . urlencode($q);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
// Nominatim requires a valid User-Agent identifying the application and a contact
$userAgent = APP_NAME . '/1.0 (' . (defined('APP_URL') ? APP_URL : 'http://localhost') . ')';
$contactEmail = 'admin@momcare.tz';
curl_setopt($ch, CURLOPT_USERAGENT, $userAgent . ' contact:' . $contactEmail);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'From: ' . $contactEmail,
    'Referer: ' . (defined('APP_URL') ? APP_URL : 'http://localhost')
]);
$resp = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE) ?: 200;
if ($resp === false) {
    http_response_code(502);
    echo json_encode(['error' => 'Failed to fetch from Nominatim']);
} else {
    http_response_code($httpCode);
    echo $resp;
}
curl_close($ch);
