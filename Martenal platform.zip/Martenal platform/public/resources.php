﻿<?php
require_once __DIR__ . '/_bootstrap.php';
$user = current_user();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = require_role(['midwife']);
    $action = post('action');
    if ($action === 'create') {
        $errors = require_post_fields(['topic', 'title', 'body']);
        if (!$errors) {
            $stmt = db()->prepare('INSERT INTO resources (topic, title, body) VALUES (?, ?, ?)');
            $stmt->execute([post('topic'), post('title'), post('body')]);
            flash('success', 'Resource added successfully.');
            redirect('resources.php');
        }
    } elseif ($action === 'delete') {
        $resourceId = (int) post('resource_id');
        db()->prepare('DELETE FROM resources WHERE id = ?')->execute([$resourceId]);
        flash('success', 'Resource deleted successfully.');
        redirect('resources.php');
    }
}
$resources = db()->query('SELECT * FROM resources ORDER BY id DESC')->fetchAll();
$resourceDetails = [
    'Antenatal' => [
        'icon' => 'bi-calendar-heart',
        'summary' => 'Antenatal care helps detect risks early, track the baby\'s growth, and prepare the family for a safer birth.',
        'points' => [
            'Start ANC as soon as pregnancy is suspected, ideally within the first 12 weeks.',
            'Keep all scheduled visits so blood pressure, weight, urine, blood level, HIV/syphilis status, and baby growth can be checked.',
            'Carry your clinic card, medicines, scan results, and questions to every visit.',
            'Ask the provider about expected delivery date, warning signs, nutrition, safe medicines, and birth planning.',
        ],
        'action' => 'Book or attend the next clinic visit if you have missed an appointment.',
    ],
    'Danger Signs' => [
        'icon' => 'bi-exclamation-triangle',
        'summary' => 'Some symptoms in pregnancy or after birth need urgent medical care and should not be watched at home.',
        'points' => [
            'Go to a health facility urgently for heavy bleeding, convulsions, fainting, severe abdominal pain, or difficulty breathing.',
            'Seek same-day care for severe headache, blurred vision, swollen face or hands, high fever, or repeated vomiting.',
            'After 20 weeks, report reduced or no baby movement immediately.',
            'After delivery, seek help for heavy bleeding, bad-smelling discharge, fever, severe pain, or thoughts of self-harm.',
        ],
        'action' => 'Use emergency transport and call your clinic contact when any danger sign appears.',
    ],
    'Nutrition' => [
        'icon' => 'bi-egg-fried',
        'summary' => 'Good nutrition supports the mother\'s strength, baby growth, blood level, and recovery after birth.',
        'points' => [
            'Eat a varied plate with staples, beans or animal protein, vegetables, fruit, and healthy fats where available.',
            'Take iron, folic acid, calcium, or other supplements exactly as advised by the clinic.',
            'Drink safe water regularly and limit alcohol, smoking, and unprescribed herbal or strong medicines.',
            'For anemia prevention, include iron-rich foods such as beans, leafy greens, sardines, meat, eggs, and fortified foods.',
        ],
        'action' => 'Ask for nutrition counselling if you feel weak, dizzy, lose weight, or cannot keep food down.',
    ],
    'Birth Plan' => [
        'icon' => 'bi-bag-heart',
        'summary' => 'A birth plan helps the family act quickly when labour starts or an emergency happens.',
        'points' => [
            'Choose the delivery facility and know the route, transport cost, and backup transport option.',
            'Prepare a hospital bag with clinic card, clean clothes, baby clothes, pads, soap, diapers, and any required supplies.',
            'Save emergency contacts for your partner, relative, transport provider, clinic, and blood donor if advised.',
            'Discuss who will care for children at home and who can accompany the mother to the facility.',
        ],
        'action' => 'Review the plan with your birth companion before the final month of pregnancy.',
    ],
    'Postpartum' => [
        'icon' => 'bi-heart-pulse',
        'summary' => 'The first six weeks after birth are important for bleeding checks, infection prevention, emotional health, and breastfeeding.',
        'points' => [
            'Attend postnatal checks, especially within the first two days and again as advised by the clinic.',
            'Monitor bleeding, pain, fever, wound healing, urination, breast pain, and emotional wellbeing.',
            'Rest when possible, eat nourishing meals, drink fluids, and accept practical support from family.',
            'Discuss family planning options before resuming sex, even if monthly periods have not returned.',
        ],
        'action' => 'Return to the facility urgently for heavy bleeding, fever, severe pain, or worsening sadness.',
    ],
    'Breastfeeding' => [
        'icon' => 'bi-droplet',
        'summary' => 'Early and frequent breastfeeding supports baby immunity, bonding, and milk production.',
        'points' => [
            'Start breastfeeding within the first hour after birth when possible.',
            'Feed on demand, day and night, and check that the baby has a deep latch with less nipple pain.',
            'Seek help for cracked nipples, breast swelling, fever, low milk concerns, or poor baby weight gain.',
            'Avoid giving other foods or drinks in the first six months unless a health worker advises differently.',
        ],
        'action' => 'Book lactation support if feeding is painful or the baby is not feeding well.',
    ],
    'Newborn' => [
        'icon' => 'bi-stars',
        'summary' => 'Newborn care focuses on warmth, safe feeding, hygiene, immunization, and early detection of illness.',
        'points' => [
            'Keep the baby warm with skin-to-skin care, clean clothes, and protection from cold air.',
            'Keep the cord clean and dry; do not apply powders, herbs, or oils unless advised by a provider.',
            'Watch for fever, low temperature, yellow eyes, fast breathing, chest indrawing, convulsions, poor feeding, or unusual sleepiness.',
            'Follow the immunization schedule and bring the child health card to every visit.',
        ],
        'action' => 'Seek urgent care if the baby refuses feeds, breathes with difficulty, or becomes very sleepy.',
    ],
    'Hygiene' => [
        'icon' => 'bi-shield-check',
        'summary' => 'Clean hands, clean supplies, and safe water reduce infection risks for the mother and baby.',
        'points' => [
            'Wash hands before breastfeeding, preparing food, changing pads, touching the cord, or handling baby items.',
            'Use clean pads and change them regularly after delivery.',
            'Clean reusable baby items with safe water and dry them well.',
            'Keep wounds and stitches clean and return to the clinic for redness, pus, swelling, or increasing pain.',
        ],
        'action' => 'Prepare soap, clean water, pads, and baby hygiene supplies before delivery.',
    ],
    'Mental Health' => [
        'icon' => 'bi-chat-heart',
        'summary' => 'Pregnancy and birth can bring emotional pressure; support is part of maternal healthcare.',
        'points' => [
            'Talk to someone trusted if you feel persistently sad, anxious, overwhelmed, or disconnected from the baby.',
            'Seek professional help if symptoms last more than two weeks or affect sleep, feeding, bonding, or daily care.',
            'Urgent help is needed for thoughts of self-harm, harming the baby, confusion, or hearing/seeing things others do not.',
            'Partners and relatives can help by reducing workload, listening without blame, and supporting clinic visits.',
        ],
        'action' => 'Book a mental wellness check if emotions feel too heavy to manage alone.',
    ],
    'Family' => [
        'icon' => 'bi-people',
        'summary' => 'Family support improves clinic attendance, rest, nutrition, emergency planning, and newborn care.',
        'points' => [
            'Partners can help with transport, appointment reminders, household work, childcare, and emergency savings.',
            'Agree on who will make decisions quickly if urgent care is needed.',
            'Support the mother to rest, eat well, breastfeed comfortably, and speak openly about symptoms.',
            'Respect privacy and encourage care from qualified health workers when warning signs appear.',
        ],
        'action' => 'Hold a short family planning conversation before the due date.',
    ],
    'Mobile Health' => [
        'icon' => 'bi-phone',
        'summary' => 'Digital reminders can support care continuity, but they should complement professional medical advice.',
        'points' => [
            'Use phone reminders for ANC visits, supplements, immunizations, medication, and postnatal checks.',
            'Keep clinic phone numbers, emergency contacts, and transport contacts saved and easy to find.',
            'Do not delay urgent care while waiting for an online reply.',
            'Protect your personal health information and share it only with trusted providers.',
        ],
        'action' => 'Set reminders for the next clinic appointment and daily supplements.',
    ],
    'Payments' => [
        'icon' => 'bi-wallet2',
        'summary' => 'Safe payment habits protect families when buying maternal products or paying for services.',
        'points' => [
            'Confirm the business name, amount, and phone number before approving mobile-money payments.',
            'Keep transaction messages until the order or service is complete.',
            'Avoid sharing PINs, one-time codes, or account passwords with anyone.',
            'Report wrong transactions quickly through the payment provider and the seller support contact.',
        ],
        'action' => 'Check order details and delivery address before confirming payment.',
    ],
];
$title = t('RESOURCES');
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <div class="section-title mb-4">
        <span class="eyebrow"><?= t('important maternal guides') ?></span>
        <h1 class="h2 mt-2 mb-2"><?= t('Health tips') ?></h1>
        <p class="text-secondary mb-0"><?= t('resources intro') ?></p>
    </div>
    <div class="alert alert-success d-flex gap-3 align-items-start mb-4">
        <i class="bi bi-info-circle-fill fs-4"></i>
        <div>
            <strong><?= t('resources.info_strong') ?></strong>
            <?= t('resources info_text') ?>
        </div>
    </div>
    <?php if ($user && $user['role_name'] === 'midwife'): ?>
        <div class="card card-body mb-4">
            <h2 class="h5"><?= t('resources.add_new_resource') ?></h2>
            <form method="post" class="row g-3">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="create">
                <div class="col-md-4"><label class="form-label"><?= t('resources.field_topic') ?></label><input class="form-control" name="topic" required></div>
                <div class="col-md-4"><label class="form-label"><?= t('resources.field_title') ?></label><input class="form-control" name="title" required></div>
                <div class="col-md-4"><label class="form-label"><?= t('resources.field_body') ?></label><textarea class="form-control" name="body" rows="1" required></textarea></div>
                <div class="col-12"><button class="btn btn-success"><?= t('resources.add_resource_button') ?></button></div>
            </form>
        </div>
    <?php endif; ?>
    <div class="row g-4">
        <?php foreach ($resources as $resource): ?>
            <?php $detail = $resourceDetails[$resource['topic']] ?? null; ?>
            <div class="col-md-6">
                <article class="card h-100"><div class="card-body">
                    <div class="d-flex align-items-start gap-3 mb-3">
                        <div class="feature-icon mb-0"><i class="bi <?= e($detail['icon'] ?? 'bi-journal-medical') ?>"></i></div>
                        <div>
                            <span class="badge bg-success-subtle text-success"><?= e($resource['topic']) ?></span>
                            <h2 class="h5 mt-2 mb-1"><?= e($resource['title']) ?></h2>
                            <p class="text-secondary mb-0"><?= e($detail['summary'] ?? $resource['body']) ?></p>
                        </div>
                    </div>
                    <?php if ($detail): ?>
                        <ul class="resource-list">
                            <?php foreach ($detail['points'] as $point): ?>
                                <li><?= e($point) ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="resource-action"><i class="bi bi-check2-circle me-2"></i><?= e($detail['action']) ?></div>
                    <?php else: ?>
                        <p><?= e($resource['body']) ?></p>
                    <?php endif; ?>
                    <?php if ($user && $user['role_name'] === 'midwife'): ?>
                        <form method="post" class="mt-3">
                            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="resource_id" value="<?= (int) $resource['id'] ?>">
                            <button class="btn btn-outline-danger btn-sm"><?= t('resources.delete_resource_button') ?></button>
                        </form>
                    <?php endif; ?>
                </div></article>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
