<?php
require_once __DIR__ . '/_bootstrap.php';

// Simple calendar API for authenticated users (customer)
$user = current_user();
if (!$user) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthenticated']);
    exit;
}

// Ensure the calendar_events table exists. Do not create it here in
// production — prefer running the SQL migration `database/calendar_events.sql`.
// If the table is missing, return appropriate responses.
$tableExists = (bool) db()->query("SHOW TABLES LIKE 'calendar_events'")->fetchColumn();
if (!$tableExists) {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        header('Content-Type: application/json');
        echo json_encode([]);
        exit;
    }
    header('Content-Type: application/json', true, 500);
    echo json_encode(['error' => 'calendar_table_missing', 'message' => 'Run database/calendar_events.sql migration']);
    exit;
}

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'GET') {
    $stmt = db()->prepare('SELECT id, title, start, `end`, all_day FROM calendar_events WHERE user_id = ?');
    $stmt->execute([(int) $user['id']]);
    $events = [];
    foreach ($stmt->fetchAll() as $row) {
        $events[] = [
            'id' => (int) $row['id'],
            'title' => $row['title'],
            'start' => $row['start'],
            'end' => $row['end'],
            'allDay' => (bool) $row['all_day'],
        ];
    }
    echo json_encode($events);
    exit;
}

// Protect POST actions with CSRF
if ($method === 'POST') {
    verify_csrf();
    $action = post('action');
    if ($action === 'create') {
        $title = post('title');
        $start = post('start');
        $end = post('end') ?: null;
        $allDay = post('all_day') === '1' ? 1 : 0;
        $notes = post('notes');
        $stmt = db()->prepare('INSERT INTO calendar_events (user_id, title, start, `end`, all_day, notes) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([(int) $user['id'], $title, $start, $end, $allDay, $notes]);
        echo json_encode(['success' => true, 'id' => (int) db()->lastInsertId()]);
        exit;
    }
    if ($action === 'delete') {
        $id = (int) post('id');
        $stmt = db()->prepare('DELETE FROM calendar_events WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, (int) $user['id']]);
        echo json_encode(['success' => true]);
        exit;
    }
    if ($action === 'update') {
        $id = (int) post('id');
        $title = post('title');
        $start = post('start');
        $end = post('end') ?: null;
        $allDay = post('all_day') === '1' ? 1 : 0;
        $stmt = db()->prepare('UPDATE calendar_events SET title = ?, start = ?, `end` = ?, all_day = ? WHERE id = ? AND user_id = ?');
        $stmt->execute([$title, $start, $end, $allDay, $id, (int) $user['id']]);
        echo json_encode(['success' => true]);
        exit;
    }
}

http_response_code(400);
echo json_encode(['error' => 'Bad request']);
