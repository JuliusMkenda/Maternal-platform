<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['customer']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = post('action');
    
    if ($action === 'mark_read') {
        $notification_id = (int) post('notification_id');
        mark_notification_read($notification_id);
        flash('success', 'Notification marked as read.');
        redirect('notifications.php');
    }
    
    if ($action === 'mark_all_read') {
        mark_all_notifications_read((int) $user['id']);
        flash('success', 'All notifications marked as read.');
        redirect('notifications.php');
    }
    
    if ($action === 'delete') {
        $notification_id = (int) post('notification_id');
        db()->prepare('DELETE FROM user_notifications WHERE id = ? AND user_id = ?')
            ->execute([$notification_id, (int) $user['id']]);
        flash('success', 'Notification deleted.');
        redirect('notifications.php');
    }
}

$notifications = get_user_notifications((int) $user['id'], 50);
$unread_count = get_unread_notification_count((int) $user['id']);

$title = 'Notifications';
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Notifications</h1>
        <?php if ($unread_count > 0): ?>
            <form method="post" class="d-inline">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="mark_all_read">
                <button class="btn btn-outline-primary btn-sm">Mark all as read</button>
            </form>
        <?php endif; ?>
    </div>
    
    <?php if (empty($notifications)): ?>
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-2"></i>
            You have no notifications yet. Check back later for updates on your orders, milestones, and new resources.
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-lg-8">
                <?php foreach ($notifications as $notif): ?>
                    <div class="card mb-3 <?= !$notif['is_read'] ? 'border-primary' : '' ?> notification-item">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="flex-grow-1">
                                    <div class="d-flex align-items-center gap-2 mb-2">
                                        <span class="badge bg-<?= match ($notif['type']) {
                                            'milestone' => 'info',
                                            'clinic_reminder' => 'warning',
                                            'new_product' => 'success',
                                            'new_resource' => 'primary',
                                            'payment' => 'success',
                                            'booking' => 'info',
                                            default => 'secondary',
                                        } ?>">
                                            <i class="bi <?= match ($notif['type']) {
                                                'milestone' => 'bi-calendar-event',
                                                'clinic_reminder' => 'bi-hospital',
                                                'new_product' => 'bi-bag-heart',
                                                'new_resource' => 'bi-journal-medical',
                                                'payment' => 'bi-wallet2',
                                                'booking' => 'bi-calendar2-check',
                                                default => 'bi-bell',
                                            } ?> me-1"></i>
                                            <?= ucfirst(str_replace('_', ' ', $notif['type'])) ?>
                                        </span>
                                        <?php if (!$notif['is_read']): ?>
                                            <span class="badge bg-danger">New</span>
                                        <?php endif; ?>
                                    </div>
                                    <h5 class="card-title mb-2"><?= e($notif['title']) ?></h5>
                                    <p class="card-text text-muted mb-2"><?= e($notif['message']) ?></p>
                                    <small class="text-muted">
                                        <i class="bi bi-clock me-1"></i>
                                        <?= date('M d, Y \a\t H:i', strtotime($notif['created_at'])) ?>
                                    </small>
                                </div>
                                <div class="ms-3">
                                    <?php if (!$notif['is_read']): ?>
                                        <form method="post" class="d-inline">
                                            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                                            <input type="hidden" name="action" value="mark_read">
                                            <input type="hidden" name="notification_id" value="<?= (int) $notif['id'] ?>">
                                            <button class="btn btn-sm btn-outline-primary" title="Mark as read">
                                                <i class="bi bi-check-circle"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="post" class="d-inline">
                                        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="notification_id" value="<?= (int) $notif['id'] ?>">
                                        <button class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-3"><i class="bi bi-info-circle me-2"></i>Notification Stats</h5>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Unread</span>
                                <strong class="text-danger"><?= $unread_count ?></strong>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar bg-danger" style="width: <?= min(100, $unread_count * 10) ?>%"></div>
                            </div>
                        </div>
                        <hr>
                        <h6 class="mb-2">Notification Types</h6>
                        <?php 
                        $type_counts = [];
                        foreach ($notifications as $n) {
                            $type_counts[$n['type']] = ($type_counts[$n['type']] ?? 0) + 1;
                        }
                        ?>
                        <small class="text-muted d-block">
                            <?php foreach ($type_counts as $type => $count): ?>
                                <div><?= ucfirst(str_replace('_', ' ', $type)) ?>: <strong><?= $count ?></strong></div>
                            <?php endforeach; ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
