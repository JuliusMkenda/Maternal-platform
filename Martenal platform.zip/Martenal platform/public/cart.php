<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['customer']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('action') === 'update') {
    foreach ($_POST['quantity'] ?? [] as $itemId => $qty) {
        $qty = max(0, (int) $qty);
        if ($qty === 0) {
            $stmt = db()->prepare('DELETE FROM cart_items WHERE id = ? AND user_id = ?');
            $stmt->execute([(int) $itemId, (int) $user['id']]);
        } else {
            $stmt = db()->prepare('UPDATE cart_items SET quantity = ? WHERE id = ? AND user_id = ?');
            $stmt->execute([$qty, (int) $itemId, (int) $user['id']]);
        }
    }
    flash('success', 'Cart updated.');
    redirect('cart.php');
}

$stmt = db()->prepare('SELECT ci.*, p.name, p.price, p.stock_quantity FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.user_id = ?');
$stmt->execute([(int) $user['id']]);
$items = $stmt->fetchAll();
$total = array_reduce($items, fn($sum, $item) => $sum + ((float) $item['price'] * (int) $item['quantity']), 0.0);

$title = 'Cart';
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <h1 class="h3 mb-3">Shopping Cart</h1>
    <form method="post">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="update">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
                <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?= e($item['name']) ?></td>
                        <td><?= money((float) $item['price']) ?></td>
                        <td><input class="form-control" style="max-width:100px" type="number" min="0" max="<?= (int) $item['stock_quantity'] ?>" name="quantity[<?= (int) $item['id'] ?>]" value="<?= (int) $item['quantity'] ?>"></td>
                        <td><?= money((float) $item['price'] * (int) $item['quantity']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$items): ?><tr><td colspan="4">Your cart is empty.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <strong>Total: <?= money($total) ?></strong>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-success">Update Cart</button>
                <?php if ($items): ?><a class="btn btn-success" href="checkout.php">Checkout</a><?php endif; ?>
            </div>
        </div>
    </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

