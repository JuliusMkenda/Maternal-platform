<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['customer']);

$orders = db()->prepare('SELECT o.*, p.escrow_status FROM orders o LEFT JOIN payments p ON p.order_id = o.id WHERE o.user_id = ? ORDER BY o.id DESC LIMIT 6');
$orders->execute([(int) $user['id']]);
$bookings = db()->prepare('SELECT b.*, s.name AS service_name FROM bookings b JOIN services s ON s.id = b.service_id WHERE b.user_id = ? ORDER BY b.booking_date DESC LIMIT 6');
$bookings->execute([(int) $user['id']]);
$notifications = get_user_notifications((int) $user['id'], 5);
$pregnancy_stats = get_pregnancy_stats((int) $user['id']);
$upcoming_milestones = $pregnancy_stats['upcoming_milestones'] ?? [];

$title = t('customer_dashboard.title');
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <?php if ($pregnancy_stats['has_pregnancy']): ?>
        <div class="row g-3 mb-4">
            <div class="col-sm-6 col-xl-3">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <div class="text-uppercase text-muted small mb-2"><?= t('Pregnancy Weeks(prenatal period)') ?></div>
                        <div class="h3 mb-0"><?= e($pregnancy_stats['weeks']) ?></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <div class="text-uppercase text-muted small mb-2"><?= t('Current phase') ?></div>
                        <div class="h3 mb-0"><?= e($pregnancy_stats['trimester_label']) ?></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <div class="text-uppercase text-muted small mb-2"><?= t('Weeks remaining') ?></div>
                        <div class="h3 mb-0"><?= e($pregnancy_stats['remaining_weeks']) ?></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <div class="text-uppercase text-muted small mb-2"><?= t('Expected delivery') ?></div>
                        <div class="h3 mb-0"><?= date('M d, Y', strtotime($pregnancy_stats['due_date'])) ?></div>
                    </div>
                </div>
            </div>
        </div>

        <?php if (!empty($upcoming_milestones)): ?>
            <div class="row g-4 mb-4">
                <div class="col-lg-8">
                    <h2 class="h5"><?= t('Upcoming Milestones') ?></h2>
                    <div class="card">
                        <div class="card-body">
                            <div class="timeline">
                                <?php foreach ($upcoming_milestones as $milestone): ?>
                                    <div class="timeline-item mb-3">
                                        <div class="d-flex gap-3">
                                            <div class="timeline-marker" style="background: <?= get_milestone_color($milestone['category']) ?>;">
                                                <i class="bi <?= get_milestone_icon($milestone['category']) ?>"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1"><?= e($milestone['title']) ?></h6>
                                                <small class="text-muted d-block"><?= format_milestone_date($milestone['milestone_date']) ?></small>
                                                <?php if ($milestone['description']): ?>
                                                    <small class="text-secondary"><?= e($milestone['description']) ?></small>
                                                <?php endif; ?>
                                            </div>
                                            <span class="badge bg-light text-muted align-self-center">
                                                <?php $days_away = (int) ((strtotime($milestone['milestone_date']) - time()) / 86400); ?>
                                                <?= $days_away > 0 ? $days_away . ' days' : 'Today' ?>
                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <h2 class="h5"><?= t('Quick Tips') ?></h2>
                    <div class="card card-body">
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="bi bi-check-circle text-success me-2"></i>
                                <small><?= t('Clinic Appointments') ?></small>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-check-circle text-success me-2"></i>
                                <small><?= t('Prenatal Vitamins') ?></small>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-check-circle text-success me-2"></i>
                                <small><?= t('Balanced Diet') ?></small>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-check-circle text-success me-2"></i>
                                <small><?= t('Danger Signs') ?></small>
                            </li>
                            <li>
                                <i class="bi bi-check-circle text-success me-2"></i>
                                <small><?= t('Hospital Bag') ?></small>
                            </li>
                        </ul>
                        <a href="resources.php" class="btn btn-outline-primary btn-sm w-100 mt-3"><?= t('Read Care Guide') ?></a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    
   
    
    <div class="row g-4">
        <div class="col-lg-6">
            <h2 class="h5"><?= t('Orders History') ?></h2>
            <div class="table-responsive"><table class="table mb-0">
                <thead><tr><th>#</th><th><?= t('Total amount') ?></th><th><?= t('Order Status') ?></th><th><?= t('Receipt') ?></th></tr></thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td>#<?= (int) $order['id'] ?></td>
                        <td><?= money((float) $order['total_amount']) ?></td>
                        <td>
                            <?= e($order['status']) ?>
                            <?php if (!empty($order['escrow_status']) && $order['escrow_status'] !== 'released'): ?>
                                <small class="text-muted d-block"><?= e($order['escrow_status']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($order['status'] === 'escrow_hold'): ?>
                                <a class="btn btn-sm btn-outline-success" href="order_confirmation.php?order=<?= (int) $order['id'] ?>">Confirm receipt</a>
                            <?php else: ?>
                                <a class="btn btn-sm btn-outline-primary" href="order_confirmation.php?order=<?= (int) $order['id'] ?>">View receipt</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
        </div>
        <div class="col-lg-6">
            <h2 class="h5"><?= t('Customer Calendar') ?></h2>
                        <div class="card mb-3">
                                <div class="card-body">
                                        <div id="calendar" style="min-height:420px;"></div>
                                </div>
                        </div>

                        <!-- Event editor modal -->
                        <div class="modal fade" id="eventModal" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title"><?= t('Customer Event') ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" id="evt-id">
                                        <div class="mb-3">
                                            <label class="form-label"><?= t('Event Title') ?></label>
                                            <input id="evt-title" class="form-control">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><?= t('Event Start') ?></label>
                                            <input id="evt-start" type="datetime-local" class="form-control">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><?= t('Event End') ?></label>
                                            <input id="evt-end" type="datetime-local" class="form-control">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-check-label"><input id="evt-all-day" type="checkbox" class="form-check-input me-2"> <?= t('Event All Day') ?></label>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label"><?= t('Add Notes') ?></label>
                                            <textarea id="evt-notes" class="form-control" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" id="evt-delete" style="display:none"><?= t('Delete') ?></button>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?= t('Cancel') ?></button>
                                        <button type="button" class="btn btn-primary" id="evt-save"><?= t('Save') ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
            <div class="table-responsive"><table class="table mb-0"><tbody>
                <?php foreach ($bookings as $booking): ?><tr><td><?= e($booking['service_name']) ?></td><td><?= e($booking['booking_date']) ?> <?= e($booking['booking_time']) ?></td><td><?= e($booking['status']) ?></td></tr><?php endforeach; ?>
            </tbody></table></div>
        </div>
        <div class="col-12">
            <h2 class="h5"><?= t('Recent notifications') ?></h2>
            <div class="table-responsive"><table class="table mb-0"><tbody>
                <?php if (empty($notifications)): ?>
                    <tr><td><em class="text-muted"><?= t('No notifications') ?></em></td></tr>
                <?php else: ?>
                    <?php foreach ($notifications as $notif): ?>
                        <tr class="<?= !$notif['is_read'] ? 'table-active' : '' ?>">
                            <td>
                                <span class="badge bg-<?= match ($notif['type']) {
                                    'milestone' => 'info',
                                    'clinic_reminder' => 'warning',
                                    'new_product' => 'success',
                                    'new_resource' => 'primary',
                                    'payment' => 'success',
                                    'booking' => 'info',
                                    default => 'secondary',
                                } ?> me-2"><?= ucfirst(str_replace('_', ' ', $notif['type'])) ?></span>
                                <strong><?= e($notif['title']) ?></strong>
                                <br>
                                <small class="text-muted"><?= e($notif['message']) ?></small>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody></table></div>
            <a href="notifications.php" class="btn btn-outline-primary btn-sm mt-2"><?= t('View All Notifications') ?></a>
        </div>
    </div>
</div>
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>

<script>
function loadScript(src, cb){
    var s = document.createElement('script');
    s.src = src;
    s.onload = function(){ cb(null); };
    s.onerror = function(){ cb(new Error('failed to load ' + src)); };
    document.head.appendChild(s);
}

function ensureFullCalendar(cb){
    if (window.FullCalendar) return cb(null);
    var fallback = 'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js';
    console.warn('FullCalendar not found, attempting to load fallback:', fallback);
    loadScript(fallback, function(err){
        if (err) console.error('Failed to load FullCalendar fallback:', err);
        cb(err);
    });
}

function pad(n){ return n<10? '0'+n : n; }
function formatDateTime(d){
    if (!d) return '';
    var year = d.getFullYear(), month = pad(d.getMonth()+1), day = pad(d.getDate());
    var hours = pad(d.getHours()), mins = pad(d.getMinutes()), secs = pad(d.getSeconds());
    return year + '-' + month + '-' + day + ' ' + hours + ':' + mins + ':' + secs;
}

function toLocalInputValue(date){
    if (!date) return '';
    var d = new Date(date);
    var year = d.getFullYear(), month = pad(d.getMonth()+1), day = pad(d.getDate());
    var hours = pad(d.getHours()), mins = pad(d.getMinutes());
    return year + '-' + month + '-' + day + 'T' + hours + ':' + mins;
}

function toServerDateTimeFromInput(val){
    if (!val) return '';
    return val.replace('T',' ') + ':00';
}

function openEventModal(mode, evt){
    var modalEl = document.getElementById('eventModal');
    var bsModal = new bootstrap.Modal(modalEl);
    document.getElementById('evt-id').value = evt && evt.id ? evt.id : '';
    document.getElementById('evt-title').value = evt && evt.title ? evt.title : '';
    document.getElementById('evt-notes').value = evt && evt.extendedProps && evt.extendedProps.notes ? evt.extendedProps.notes : '';
    document.getElementById('evt-start').value = evt && evt.start ? toLocalInputValue(evt.start) : '';
    document.getElementById('evt-end').value = evt && evt.end ? toLocalInputValue(evt.end) : '';
    document.getElementById('evt-all-day').checked = evt && (evt.allDay || evt.all_day);
    if (mode === 'create') {
        document.getElementById('evt-delete').style.display = 'none';
    } else {
        document.getElementById('evt-delete').style.display = 'inline-block';
    }

    document.getElementById('evt-save').onclick = function(){
        var id = document.getElementById('evt-id').value;
        var title = document.getElementById('evt-title').value.trim();
        var notes = document.getElementById('evt-notes').value.trim();
        var allDay = document.getElementById('evt-all-day').checked ? '1' : '0';
        var start = toServerDateTimeFromInput(document.getElementById('evt-start').value);
        var end = toServerDateTimeFromInput(document.getElementById('evt-end').value);
        var action = id ? 'update' : 'create';
        var fd = new FormData();
        fd.append('csrf', '<?= e(csrf_token()) ?>');
        fd.append('action', action);
        if (id) fd.append('id', id);
        fd.append('title', title);
        fd.append('notes', notes);
        fd.append('all_day', allDay);
        fd.append('start', start);
        fd.append('end', end);
        fetch('calendar_api.php', {method: 'POST', body: fd}).then(r => r.json()).then(function(res){
            if (res.success) { window.calendar && window.calendar.refetchEvents(); bsModal.hide(); } else { alert('<?= e(t('customer_dashboard.calendar_event_create_error')) ?>'); }
        }).catch(function(){ alert('<?= e(t('customer_dashboard.calendar_event_create_error')) ?>'); });
    };

    document.getElementById('evt-delete').onclick = function(){
        var id = document.getElementById('evt-id').value;
        if (!id) return;
        if (!confirm('<?= e(t('customer_dashboard.calendar_delete_confirm')) ?>')) return;
        var fd = new FormData();
        fd.append('csrf', '<?= e(csrf_token()) ?>');
        fd.append('action', 'delete');
        fd.append('id', id);
        fetch('calendar_api.php', {method: 'POST', body: fd}).then(r => r.json()).then(function(res){
            if (res.success) { window.calendar && window.calendar.refetchEvents(); bsModal.hide(); } else { alert('<?= e(t('customer_dashboard.calendar_event_delete_error')) ?>'); }
        });
    };

    bsModal.show();
}

function initCalendar(){
    var calendarEl = document.getElementById('calendar');
    if (!calendarEl) return;

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        selectable: true,
        editable: true,
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        dateClick: function(info) {
            openEventModal('create', {start: info.date});
        },
        eventClick: function(info) {
            openEventModal('edit', info.event);
        },
        eventDrop: function(info) {
            var fd = new FormData();
            fd.append('csrf', '<?= e(csrf_token()) ?>');
            fd.append('action', 'update');
            fd.append('id', info.event.id);
            fd.append('title', info.event.title || '');
            fd.append('start', formatDateTime(info.event.start));
            fd.append('end', info.event.end ? formatDateTime(info.event.end) : '');
            fd.append('all_day', info.event.allDay ? '1' : '0');
            fetch('calendar_api.php', {method: 'POST', body: fd}).then(r => r.json()).then(function(res){
                if (!res.success) { alert('<?= e(t('customer_dashboard.calendar_event_update_error')) ?>'); info.revert(); }
            });
        },
        eventResize: function(info) {
            var fd = new FormData();
            fd.append('csrf', '<?= e(csrf_token()) ?>');
            fd.append('action', 'update');
            fd.append('id', info.event.id);
            fd.append('title', info.event.title || '');
            fd.append('start', formatDateTime(info.event.start));
            fd.append('end', info.event.end ? formatDateTime(info.event.end) : '');
            fd.append('all_day', info.event.allDay ? '1' : '0');
            fetch('calendar_api.php', {method: 'POST', body: fd}).then(r => r.json()).then(function(res){
                if (!res.success) { alert('<?= e(t('customer_dashboard.calendar_event_update_error')) ?>'); info.revert(); }
            });
        },
        events: function(info, successCallback, failureCallback) {
            fetch('calendar_api.php').then(r => r.json()).then(function(data){
                successCallback(data);
            }).catch(function(){ failureCallback([]); });
        }
    });

    calendar.render();
    window.calendar = calendar;
}

window.addEventListener('load', function(){
    ensureFullCalendar(function(err){
        if (err) {
            console.error('FullCalendar failed to load. Check network/CSP or CDN URL.');
            return; // don't attempt to initialize
        }
        if (!window.FullCalendar) { console.error('FullCalendar still undefined after fallback.'); return; }
        initCalendar();
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>

