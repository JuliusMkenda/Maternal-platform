<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['customer']);
$orderId = (int) getv('order', '0');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('action') === 'confirm_received') {
    $stmt = db()->prepare('SELECT status FROM orders WHERE id = ? AND user_id = ?');
    $stmt->execute([$orderId, (int) $user['id']]);
    $orderStatus = $stmt->fetchColumn();

    if ($orderStatus === 'escrow_hold') {
        db()->beginTransaction();
        db()->prepare('UPDATE orders SET status = "confirmed", receipt_confirmed_at = NOW() WHERE id = ?')->execute([$orderId]);
        db()->prepare('UPDATE payments SET escrow_status = "release_scheduled", payout_status = "scheduled", escrow_released_at = DATE_ADD(NOW(), INTERVAL 12 HOUR), payout_date = DATE_ADD(NOW(), INTERVAL 12 HOUR) WHERE order_id = ? AND escrow_status = "held"')->execute([$orderId]);
        db()->commit();
        flash('success', 'Receipt confirmed. Funds are scheduled for payout in 12 hours.');
    } else {
        flash('error', 'Order cannot be confirmed at this time.');
    }
    redirect('order_confirmation.php?order=' . $orderId);
}

$stmt = db()->prepare('SELECT o.*, p.escrow_status, p.escrow_released_at, p.payout_status, p.payout_date, p.transaction_reference, p.method, p.phone AS payment_phone FROM orders o LEFT JOIN payments p ON p.order_id = o.id WHERE o.id = ? AND o.user_id = ?');
$stmt->execute([$orderId, (int) $user['id']]);
$order = $stmt->fetch();

$items = [];
if ($order) {
    $itemsStmt = db()->prepare('SELECT oi.quantity, oi.unit_price, p.name FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?');
    $itemsStmt->execute([$orderId]);
    $items = $itemsStmt->fetchAll();
}

if ($order && $order['escrow_status'] === 'release_scheduled' && $order['escrow_released_at'] !== null && new DateTime() >= new DateTime($order['escrow_released_at'])) {
    db()->prepare('UPDATE payments SET escrow_status = "released", payout_status = "paid", payout_date = NOW() WHERE order_id = ? AND escrow_status = "release_scheduled"')->execute([$orderId]);
    $order['escrow_status'] = 'released';
    $order['payout_status'] = 'paid';
    $order['payout_date'] = date('Y-m-d H:i:s');
}

$title = 'Order Confirmation';
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <?php if ($order): ?>
        <div class="card card-body mb-4">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h1 class="h3">Order Receipt #<?= (int) $order['id'] ?></h1>
                    <p class="mb-1">Placed: <?= e($order['created_at']) ?></p>
                    <p class="mb-1">Delivery: <?= e($order['delivery_address']) ?></p>
                    <?php if (!empty($order['delivery_lat']) && !empty($order['delivery_lng'])): ?>
                        <p class="mb-1">Location: <?= e($order['delivery_lat']) ?>, <?= e($order['delivery_lng']) ?></p>
                    <?php endif; ?>
                    <p class="mb-0">Status: <strong><?= e($order['status']) ?></strong></p>
                </div>
                <a class="btn btn-outline-secondary" href="javascript:window.print()">Print receipt</a>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-lg-6">
                <div class="card card-body mb-4">
                    <h2 class="h5">Payment Details</h2>
                    <p>Amount: <strong><?= money((float) $order['total_amount']) ?></strong></p>
                    <p>Payment method: <strong><?= e($order['method'] ?? 'M-Pesa Sandbox') ?></strong></p>
                    <p>Transaction reference: <strong><?= e($order['transaction_reference'] ?? 'N/A') ?></strong></p>
                    <p>Settlement account: <strong>Admin Escrow Account</strong></p>
                    <p>Mobile number: <strong><?= e($order['payment_phone'] ?? 'N/A') ?></strong></p>
                    <?php if (!empty($order['escrow_status'])): ?>
                        <p>Escrow status: <strong><?= e($order['escrow_status']) ?></strong></p>
                    <?php endif; ?>
                    <?php if ($order['escrow_status'] === 'release_scheduled'): ?>
                        <div class="alert alert-info">Funds are scheduled for release at <?= e($order['escrow_released_at']) ?>.</div>
                    <?php elseif ($order['escrow_status'] === 'released'): ?>
                        <div class="alert alert-success">Escrow funds have been released.</div>
                    <?php endif; ?>
                </div>
                <div class="card card-body mb-4">
                    <h2 class="h5">Order items</h2>
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead><tr><th>Product</th><th>Qty</th><th>Price</th></tr></thead>
                            <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td><?= e($item['name']) ?></td>
                                    <td><?= (int) $item['quantity'] ?></td>
                                    <td><?= money((float) $item['unit_price']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card card-body mb-4">
                    <h2 class="h5">Receipt confirmation</h2>
                    <p>This page serves as your receipt and delivery confirmation document. Save or print it for proof of payment and delivery.</p>
                    <?php if ($order['status'] === 'escrow_hold'): ?>
                        <div class="alert alert-warning">Your payment is held in escrow until you confirm safe receipt of the goods.</div>
                        <form method="post">
                            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                            <input type="hidden" name="action" value="confirm_received">
                            <button class="btn btn-success">I have received the goods safely</button>
                        </form>
                    <?php elseif ($order['status'] === 'confirmed' && $order['escrow_status'] === 'release_scheduled'): ?>
                        <div class="alert alert-info">Release is scheduled in 12 hours.</div>
                    <?php elseif ($order['status'] === 'confirmed' && $order['escrow_status'] === 'released'): ?>
                        <div class="alert alert-success">Escrow funds have been released for seller payment.</div>
                    <?php elseif ($order['escrow_status'] === 'held'): ?>
                        <div class="alert alert-info">Hold is active. Awaiting your receipt confirmation.</div>
                    <?php endif; ?>
                    <a class="btn btn-outline-secondary mt-3" href="orders.php">Back to orders</a>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger">Order not found.</div>
    <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

