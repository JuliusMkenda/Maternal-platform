<?php
require_once __DIR__ . '/_bootstrap.php';
$user = require_role(['admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = post('type');
    $id = (int) post('id');
    $status = post('status');

    if ($type === 'user' && in_array($status, ['active', 'inactive'], true)) {
        db()->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$status, $id]);
    }
    if ($type === 'product' && in_array($status, ['active', 'inactive'], true)) {
        db()->prepare('UPDATE products SET status = ? WHERE id = ?')->execute([$status, $id]);
    }
    if ($type === 'order' && in_array($status, ['pending_payment', 'escrow_hold', 'confirmed', 'processing', 'delivered', 'cancelled'], true)) {
        db()->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, $id]);
    }
    if ($type === 'release_escrow') {
        db()->prepare('UPDATE payments SET escrow_status = "released", payout_status = "paid", payout_date = NOW() WHERE order_id = ? AND escrow_status = "release_scheduled"')->execute([$id]);
        flash('success', 'Escrow funds marked as released and payout completed.');
        redirect('admin_manage.php');
    }
    flash('success', 'Record updated.');
    redirect('admin_manage.php');
}

$users = db()->query('SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id ORDER BY u.id DESC')->fetchAll();
$products = db()->query('SELECT id, name, status FROM products ORDER BY id DESC')->fetchAll();
$orders = db()->query('SELECT o.id, o.total_amount, o.status, p.escrow_status, p.escrow_released_at, p.payout_status, p.payout_date FROM orders o LEFT JOIN payments p ON p.order_id = o.id ORDER BY o.id DESC')->fetchAll();

$title = 'Admin Management';
include __DIR__ . '/../includes/header.php';
?>
<div class="container pb-5">
    <h1 class="h3 mb-3">Manage Products, Users, and Orders</h1>
    <div class="row g-4">
        <div class="col-lg-4">
            <h2 class="h5">Users</h2>
            <?php foreach ($users as $row): ?>
                <form class="card card-body mb-2" method="post">
                    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                    <input type="hidden" name="type" value="user"><input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                    <strong><?= e($row['full_name']) ?></strong><small><?= e($row['role_name']) ?></small>
                    <select class="form-select form-select-sm my-2" name="status"><option <?= $row['status'] === 'active' ? 'selected' : '' ?>>active</option><option <?= $row['status'] === 'inactive' ? 'selected' : '' ?>>inactive</option></select>
                    <button class="btn btn-sm btn-success">Save</button>
                </form>
            <?php endforeach; ?>
        </div>
        <div class="col-lg-4">
            <h2 class="h5">Products</h2>
            <?php foreach ($products as $row): ?>
                <form class="card card-body mb-2" method="post">
                    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                    <input type="hidden" name="type" value="product"><input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                    <strong><?= e($row['name']) ?></strong>
                    <select class="form-select form-select-sm my-2" name="status"><option <?= $row['status'] === 'active' ? 'selected' : '' ?>>active</option><option <?= $row['status'] === 'inactive' ? 'selected' : '' ?>>inactive</option></select>
                    <button class="btn btn-sm btn-success">Save</button>
                </form>
            <?php endforeach; ?>
        </div>
        <div class="col-lg-4">
            <h2 class="h5">Orders</h2>
            <?php foreach ($orders as $row): ?>
                <form class="card card-body mb-2" method="post">
                    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                    <input type="hidden" name="type" value="order"><input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                    <strong>#<?= (int) $row['id'] ?> · <?= money((float) $row['total_amount']) ?></strong>
                    <select class="form-select form-select-sm my-2" name="status">
                        <?php foreach (['pending_payment','escrow_hold','confirmed','processing','delivered','cancelled'] as $status): ?><option <?= $row['status'] === $status ? 'selected' : '' ?>><?= e($status) ?></option><?php endforeach; ?>
                    </select>
                    <button class="btn btn-sm btn-success">Save</button>
                </form>
                <?php if ($row['escrow_status'] === 'release_scheduled'): ?>
                    <form class="card card-body mb-2" method="post">
                        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                        <input type="hidden" name="type" value="release_escrow">
                        <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                        <button class="btn btn-sm btn-outline-primary">Release escrow funds</button>
                        <div class="text-muted small mt-1">Release scheduled at <?= e($row['escrow_released_at']) ?></div>
                    </form>
                <?php endif; ?>
                <?php if (!empty($row['payout_status'])): ?>
                    <div class="card card-body mb-2">
                        <strong>Payout:</strong> <?= e($row['payout_status']) ?>
                        <?php if (!empty($row['payout_date'])): ?><div class="text-muted small"><?= e($row['payout_date']) ?></div><?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>

